@echo off
cd /d "%~dp0"
python try_horseman_motion_study.py --pack "%~dp0"
if errorlevel 1 pause
