# Independent audit: Horseman Motion Study

**Verdict: accepted, round 1.** No high-severity actionable artwork, motion, encoding, or preview findings remain for `horseman-motion-color-stable-v7`. This acceptance covers the three proof roles (pointer, link, busy). It does not approve equipping a cursor or certify automatic playback.

## What was independently tested

- Loaded each delivered ANI from disk with Windows `LoadImageW` at 32, 48, and 64 pixels. Forced every `DrawIconEx` index on black and white: 120 indices per size, 360 native frame pairs per pack. Recovered RGBA from the black/white difference and saved all native frames under `native/`.
- Parsed every ANI RIFF/CUR/DIB resource: 24-bit BGR and one-bit AND masks at 32/48/64. Compared visible RGB and masks of all 360 embedded resources against the resized, alpha-thresholded delivered source composites. Native 64px visible pixels exactly match the delivered source composites. The native32 disk-loader result is reviewed as delivered; selection of the separately prepared embedded32 resource is not assumed.
- Checked every native frame for binary effective opacity, opaque/fixed click pixel and empty canvas edges. All pass at all three sizes. The authored 5x5 saddle patch is invariant at native64; at smaller sizes only the click pixel, rather than a rescaled 5x5 neighborhood, is required to remain fixed.
- Compared all native transparent GIF masks to fresh native renders. All masks match exactly. Tested every native invariant opaque pixel for color flicker against fresh renders and the preserved pre-turn baseline. Current flickering invariant-pixel count and channel span are zero for every role/size.
- Parsed all current GIF block tables, disposal/transparency controls and stored delays. Each quantized animation has one shared palette, no per-frame palette drift, disposal=2, transparent index zero, and binary decoded alpha. A separate hidden-RGB probe confirms clear pixels do not affect the selected palette.
- Checked the shared source grading: all six still-piece alpha channels are unchanged by `rich_materials`; loader grading is the same fixed operation for both horses before resizing/deformation. Delivered still pieces match original assets. Pointer and hand illustrations are not accidentally horse-graded.
- Ran the delivered trial helper with `--check-load` on exact copies under `trial_load/`. It loaded all three ANI files at32 and64, created no window, and changed no scheme. This proves loading only.
- Verified all identity/source/implementation/preview/trial/validation hashes, and measured every release artifact in `audit_acceptance.json`. Registry cursor/mouse/accessibility values equal both audit-start values and the preserved baseline.

## Visual and implementation review

Viewed the actual native 32px and64px contact sheets and new audit grids for every index, source composite contact sheets, six generated still pieces, current HTML screenshot, and current GIF frame data. The rigid arrow retains aligned head/shaft and its contact point. The pointing gauntlet keeps a readable index/hand silhouette with stationary fingertip and animated cuff ornaments. The shared gallop has attached, substantial forelegs and a continuous torso/shoulder mass through support and recovery. Far legs retain intentional depth shading. Flame tail, cape and cuff/heel flame roots remain attached in the reviewed composites; no canvas clipping was found. Horse muzzle/ear/tack and pumpkin accents remain readable at64px; fine face/trim detail collapses to very few pixels at32px. This is a retained resolution limit, rather than newly drawn facial acting.

The six horse PNG pieces each contain one generated still illustration. The delivered 24-frame gallop and48-frame stomp are kinematic rig composites using those pieces; pointer and hand use one still source each with isolated ornaments and periodic image warps. These are not independently drawn source poses, and flame motion is not physical simulation.

Measured wrap transitions fall within ordinary adjacent-frame channel-delta ranges. For the shared gallop at64px the seam changes1216 pixels versus an ordinary adjacent mean1192.3; seam mean RGBA-channel delta6.35 versus maximum ordinary7.56. These pixel measures and pose-grid inspection did not reveal a special wrap jump. They do not prove fluid character motion or human-perceived cadence.

## Color and stored timing results

| Role | Native invariant opaque pixels, 32/48/64 | Baseline GIF flicker count, 32/48/64 | Current GIF flicker count | ANI/GIF loop |
|---|---:|---:|---:|---:|

| pointer | 175/389/695 | 0/322/619 | 0/0/0 | 1600 ms |

| link | 247/556/1006 | 238/541/998 | 0/0/0 | 1600 ms |

| busy | 4/16/25 | 4/16/25 | 0/0/0 | 800 ms |


Native ANI timing remains2 jiffies per frame (nominal30fps). GIF delays alternate the necessary30/40ms centisecond values without changing total loop length: pointer/link1600ms, busy800ms. The combined review is1600ms with the busy loop repeated twice. Browser wall-clock timing was not measured. GIF palettes remain lossy to native true color: see per-size maximum quantization differences in `measurements.json`; stability does not mean pixel-identical RGB.

The MotionStudy busy baseline on disk lagged an already-authored foreleg anatomy revision: current versus its own baseline changes535 source/native64 alpha pixels over the full24-frame cycle (native32:133, native48:293). This is propagation of the existing shared rig. The color-only control is StompStudy `audits/color_stability/before/busy.ani` and its source frames: native/source mask changes are zero at32/48/64 against that reference. Current busy ANI bytes are identical in the two packs. Pointer and hand masks also match MotionStudy's own baseline.

## Browser preview review

The auditor reviewed the HTML/CSS/JavaScript, referenced GIF dimensions and supplied live-browser JSON/screenshot evidence. The parent agent operated the live browser. All nine images load at native32/native64 and labelled128px nearest inspection; CSS opacity is1 and filters are absent at DPR1. Live MotionStudy evidence covers image sizes/styles and White background; full toolbar/control behavior was exercised on the shared Stomp preview implementation. Descriptions match the current arrow/hand/gallop art and there is no obsolete banner. The target pad correctly uses a static native32 PNG and does not claim browser ANI playback. Browser wall-clock cadence remains unmeasured.

## Exact accepted bytes

| Delivered ANI | SHA256 |
|---|---|

| busy.ani | `2625c7f8588a18be3a5353950a6866f5fbc2f812b29599eb4dc1f2aab4a66ef4` |

| link.ani | `1090400b60766b01499cc57459aa37d1d8a203f4173b15b5540449fc74a9f61b` |

| pointer.ani | `50baad107c2563e7d53d1cacb012b348886f849c373a105378d41d9446f78729` |


| Binding | SHA256 |
|---|---|

| build_identity.json | `0d73905798fdcfb591bb2b38d4ab73523869d9b1ca48362360526904256a9e4d` |

| preview.html | `a797b16c6aacc2641e98d928478294f243c1914ac2e67590988edc80c6198f20` |

| animation_manifest.json | `63c4a9c465fded1035f1db9dafcd137ab0ddf517c6b307df86c35b69e96a613c` |

| review.gif | `40eac16c59b33052f0dc02e47857fc6be23d5e30496f6c6c5df6cf0dbfadb888` |


| Reviewed implementation | SHA256 |
|---|---|

| engine/horseman_motion_study.py | `9e99f24693528b9d12b4311394c95fd112bdc4d4413219456acd72d57751c324` |

| engine/horseman_motion_preview.py | `745e9f00210c74fdb8ff0350c48cfe36fe33023b5bcf5eef2b73096341e7d069` |

| engine/horseman_color.py | `a2d0de5fef5be14163d95a2c88d33b4f7e69a56d4998cec6b477328667d626fd` |

| engine/preview_gen.py | `39456e8a5c05d7b3ff318fb18cea40fbab2119d275cc9eb12d8d048a95a23a5c` |

| engine/ani_compiler.py | `686981d0c1c927079814d338a14141fe892129c36f37be3036aa099fccf6b9f3` |

| validate_muse_pack.py | `98a4c6a03be5d0764d4ff283f464d37219b12c8170947d82f6b16fe779f17468` |

| verify_pack.py | `7f40ecf43af61cecf812fa1b90ebb6589e8d9417c1ad8fd5eed6939dc1d3f893` |

| try_horseman_motion_study.py | `daf43e9e5be47913f496d91617bfadd49dbbe27897a083f63c2d7bd0372d3dae` |

| build_horseman_motion_study.py | `cbd823efc03dddcf1a413b26dfe9bfc94f1eef2f4acc789118702d40034b8c5b` |


All source composites, copied original sources, previews, validation records, native sheets, README and packaged trial files are individually bound by `artifact_files` in `audit_acceptance.json`. Supplied browser/color evidence is individually bound by `evidence_files`. The detailed actual-native measurements and scripts are retained beside this report.

## Findings and limits

No P0/P1 artwork, motion, encoding, or preview findings remain. No rebuild was needed after independent review. Remaining disclosed limits are dense face/trim detail at32px, GIF palette color loss, unmeasured browser wall-clock cadence, unverified automatic window/equipped playback, unverified human aiming accuracy and unverified fluid character motion. No cursor scheme was changed and no native trial window was opened.
