# Supplemental release/preflight review

The two P2 guard findings from the first static review are resolved in the actual updated files: safety/hash conditions now raise explicit exceptions that remain active under Python optimization, and acceptance binds every packaged production artifact including copied source art, composite PNGs, README, native sheets and trial files.

The final guard also verifies the accepted AUDIT.md hash and all three supplied browser/color evidence hashes. Packaging checks the bytes it actually reads against those acceptance maps, refuses unreviewed production artifacts, checks implementation bytes again, and verifies ZIP CRCs and every member checksum after writing. Historical before snapshots are excluded.

The `--check-review` branch returns before cursor loading, registry writes, cursor reload or SetSystemCursor. Imported settings code declares APIs and functions without changing cursor settings. The application branch itself was not run. The isolated rejection script mutates only copies in a verified workspace temporary directory and checks stale source bytes, changed build identity and accepted=false rejection. The parent agent reports successful normal and `python -O` rejection suites and normal/optimized preflight; this supplemental auditor reviewed those actual scripts statically rather than repeating the parent's dynamic checks.

| Final reviewed root implementation | SHA256 |
|---|---|
| reviewed_cursor_release.py | `f99b70c8f80ad78b3881a77e3d8e7462a7a95a4b579d5f80db03e034fcbfdb80` |
| package_horseman_color_stable.py | `9c4cc9428cb21a27cce65e9f263ec9b6fcb792b913f05932612254ac55569954` |
| apply_reviewed_stomp.py | `f582ecaa38d9be160770915e16330a0fc4fa4912d231cf78210585b74009f68e` |
| verify_cursor_release_guard.py | `62c37d4f3c965c77fcae2ec4d6c07b4e14d3f666be197ee2678c60a7dd20bc4f` |

No unresolved actionable guard finding remains in this reviewed scope. Release ZIP bytes are checked separately after packaging. Automatic equipped playback, application rollback behavior, browser wall-clock cadence and human aiming accuracy remain outside this static guard review.
