"""Independent, read-only production audit. Writes evidence only below round1."""
import argparse
import hashlib
import json
import re
import struct
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageSequence

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT))
from check_horseman_color import native_apis, scheme_state
from validate_muse_pack import draw_icon, icon_info, riff_chunks
from engine.horseman_color import HORSE_PARTS, rich_materials
from engine import horseman_motion_study as motion


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def frames(path):
    with Image.open(path) as im:
        return [np.array(frame.convert('RGBA')) for frame in ImageSequence.Iterator(im)], [frame.info.get('duration') for frame in ImageSequence.Iterator(im)]


def parse_ani(path):
    raw = path.read_bytes()
    assert raw[:4] == b'RIFF' and raw[8:12] == b'ACON'
    assert struct.unpack_from('<I', raw, 4)[0] == len(raw) - 8
    metadata, rate, seq, resources = {}, [], [], []
    for tag, body, length in riff_chunks(raw, 12, len(raw)):
        if tag == b'anih':
            fields = struct.unpack_from('<9I', raw, body)
            metadata = dict(frames=fields[1], steps=fields[2], default_jiffies=fields[7], flags=fields[8])
        if tag in (b'rate', b'seq '):
            values = list(struct.unpack_from(f'<{length//4}I', raw, body))
            if tag == b'rate': rate = values
            else: seq = values
        if tag == b'LIST' and raw[body:body+4] == b'fram':
            for stag, sbody, slength in riff_chunks(raw, body+4, body+length):
                assert stag == b'icon'
                cur = raw[sbody:sbody+slength]
                assert struct.unpack_from('<3H', cur, 0)[:2] == (0, 2)
                count = struct.unpack_from('<H', cur, 4)[0]
                resource = {}
                for entry in range(count):
                    w, h, _, _, hx, hy, dlen, offset = struct.unpack_from('<4B2H2I', cur, 6+entry*16)
                    w, h = w or 256, h or 256
                    dib = cur[offset:offset+dlen]
                    dsize, dw, dh, planes, depth, compression = struct.unpack_from('<IiiHHI', dib, 0)
                    assert (dsize, dw, dh, planes, depth, compression) == (40, w, 2*h, 1, 24, 0)
                    cstride, mstride = ((w*24+31)//32)*4, ((w+31)//32)*4
                    assert len(dib) == 40 + (cstride+mstride)*h
                    bgr = np.frombuffer(dib[40:40+cstride*h], np.uint8).reshape(h, cstride)[:, :w*3].reshape(h, w, 3)[::-1]
                    mask = np.frombuffer(dib[40+cstride*h:], np.uint8).reshape(h, mstride)[::-1]
                    alpha = (1-np.unpackbits(mask, axis=1)[:, :w])*255
                    resource[w] = (np.dstack((bgr[:, :, ::-1], alpha)), [hx, hy])
                assert set(resource) == {32, 48, 64}
                resources.append(resource)
    assert len(resources) == metadata['frames']
    metadata['step_jiffies'] = rate or [metadata['default_jiffies']] * metadata['steps']
    metadata['sequence'] = seq or list(range(metadata['steps']))
    metadata['loop_ms'] = sum(metadata['step_jiffies']) * 1000 / 60
    return metadata, resources


def native_frames(path, output=None):
    metadata, _ = parse_ani(path)
    u, g = native_apis()
    result = {}
    for size in (32, 48, 64):
        handle = u.LoadImageW(None, str(path), 2, size, size, 0x10)
        assert handle, (path, size)
        info = icon_info(u, g, handle)
        data = []
        try:
            for index in range(metadata['steps']):
                black = np.array(draw_icon(u, g, handle, size, 0, index).convert('RGB'), np.int16)
                white = np.array(draw_icon(u, g, handle, size, 0xffffff, index).convert('RGB'), np.int16)
                delta = white-black
                opaque, clear = np.all(delta == 0, axis=2), np.all(delta == 255, axis=2)
                assert np.all(opaque | clear), (path, size, index, 'partial native opacity')
                arr = np.dstack((black.astype(np.uint8), opaque.astype(np.uint8)*255))
                if output:
                    dest = output/f'{path.stem}_native{size}'
                    dest.mkdir(exist_ok=True, parents=True)
                    Image.fromarray(arr).save(dest/f'{index:02}.png')
                data.append(arr)
        finally:
            u.DestroyIcon(handle)
        result[str(size)] = (info, data)
    return metadata, result


def fixed_color_metrics(native, decoded):
    native, decoded = np.stack(native), np.stack(decoded)
    fixed = np.all(native == native[0], axis=(0, 3)) & (native[0, :, :, 3] == 255)
    changed = np.any(decoded[:, :, :, :3] != decoded[0, :, :, :3], axis=(0, 3)) & fixed
    span = decoded[:, :, :, :3].max(axis=0).astype(int)-decoded[:, :, :, :3].min(axis=0).astype(int)
    return dict(native_fixed_opaque_pixels=int(fixed.sum()), gif_flickering_fixed_pixels=int(changed.sum()),
                maximum_fixed_rgb_channel_span=int(span[fixed].max()) if fixed.any() else 0)


def changes(data):
    diffs = [int(np.count_nonzero(np.any(data[(i+1)%len(data)] != data[i], axis=2))) for i in range(len(data))]
    error = [float(np.abs(data[(i+1)%len(data)].astype(float)-data[i]).mean()) for i in range(len(data))]
    return dict(adjacent_changed_pixels_including_seam=diffs, seam_changed_pixels=diffs[-1],
                mean_adjacent_changed_pixels=float(np.mean(diffs[:-1])), seam_mean_rgba_channel_delta=error[-1],
                max_adjacent_mean_rgba_channel_delta=max(error[:-1]))


def sheet(data, dest, size):
    scale = 2 if size == 64 else 4
    tile = size*scale
    columns, rows = 8, (len(data)+7)//8
    out = Image.new('RGB', (columns*(tile+8), rows*(tile+25)), '#37313f')
    draw = ImageDraw.Draw(out)
    for i, frame in enumerate(data):
        x, y = (i%columns)*(tile+8), (i//columns)*(tile+25)
        # Alternate backgrounds to inspect outline/contact/flame roots.
        bg = Image.new('RGBA', (size,size), '#fff' if i%2 == 0 else '#211b29')
        bg.alpha_composite(Image.fromarray(frame))
        out.paste(bg.convert('RGB').resize((tile,tile), Image.Resampling.NEAREST), (x,y+18))
        draw.text((x+2,y), f'{i:02}', fill='#e9cfa0')
    out.save(dest)


def main(pack):
    out = pack/'audits'/'color_stability'/'round1'
    out.mkdir(parents=True, exist_ok=True)
    initial_scheme = scheme_state()
    identity = json.loads((pack/'build_identity.json').read_text())
    hashes = {}
    for bucket in ('files', 'source_files', 'implementation_files', 'preview_files', 'validation_files', 'trial_files'):
        hashes[bucket] = {}
        for name, expected in identity[bucket].items():
            path = ROOT/name if bucket in ('source_files','implementation_files') else pack/name
            actual = sha(path)
            hashes[bucket][name] = actual
            assert actual == expected, (bucket, name, actual, expected)
    hashes['artifacts'] = {name: sha(pack/name) for name in ('animation_manifest.json','build_identity.json','preview.html','review.gif','source_contact.png','windows_render_check_32px.png','windows_render_check_64px.png','native_backgrounds_32px.png','native_backgrounds_64px.png')}
    for field, name in [('preview_sha256','preview.html'),('manifest_sha256','animation_manifest.json'),('review_gif_sha256','review.gif'),('inspection_gif_sha256','stomp-rich-color.gif')]:
        if field in identity:
            assert sha(pack/name) == identity[field]
            hashes['artifacts'][name] = sha(pack/name)
    hashes['composite_sources'] = {path.relative_to(pack).as_posix():sha(path) for path in sorted((pack/'sources').glob('*.png'))}
    report = dict(art_version=identity['art_version'], exact_hashes=hashes, identity_matches=True, roles={}, source_grading={})
    for part in sorted(HORSE_PARTS):
        raw = Image.open(ROOT/'assets'/'horseman_motion_study'/f'{part}.png').convert('RGBA')
        grade = rich_materials(raw)
        assert np.array_equal(np.array(raw)[:,:,3],np.array(grade)[:,:,3])
        expected = raw.copy()
        expected.putalpha(expected.getchannel('A').point(lambda a:a if a>=128 else 0))
        expected = rich_materials(expected)
        assert np.array_equal(np.array(expected), np.array(motion.load(part)))
        delivered = pack/'source_art'/f'{part}.png'
        assert sha(delivered) == sha(ROOT/'assets'/'horseman_motion_study'/f'{part}.png')
        report['source_grading'][part] = dict(alpha_preserved_by_grading=True, shared_load_matches_grade=True,
            delivered_still_matches_source=True, still_sha256=sha(delivered))
    for name in ('link-source','pointer-source-straight-v3'):
        expected = Image.open(ROOT/'assets'/'horseman_motion_study'/f'{name}.png').convert('RGBA')
        expected.putalpha(expected.getchannel('A').point(lambda a:a if a>=128 else 0))
        assert np.array_equal(np.array(expected), np.array(motion.load(name)))
    baseline = pack/'audits'/'color_stability'/'before'
    for role in ('pointer','link','busy'):
        metadata, resources = parse_ani(pack/f'{role}.ani')
        _, native = native_frames(pack/f'{role}.ani', out/'native')
        before_meta, before_native = native_frames(baseline/f'{role}.ani')
        source = [np.array(Image.open(path).convert('RGBA')) for path in sorted((pack/'sources').glob(f'{role}_*.png'))]
        before_source = [np.array(Image.open(path).convert('RGBA')) for path in sorted((baseline/'sources').glob(f'{role}_*.png'))]
        assert metadata == before_meta, (role, 'ANI temporal metadata changed')
        assert len(source) == metadata['frames']
        rec = dict(ani_sha256=sha(pack/f'{role}.ani'), metadata=metadata, sizes={},
                   source_alpha_changes_vs_before=sum(int(np.count_nonzero(a[:,:,3]!=b[:,:,3])) for a,b in zip(source,before_source)))
        reference_native = before_native
        if pack.name == 'HorsemanMotionStudy' and role == 'busy':
            # Its baseline disk outputs lagged the already-authored foreleg revision.
            # Use the Stomp pack's same pre-turn rig for the color-only shape test.
            reference_pack = ROOT/'cursor_sets'/'HorsemanStompStudy'/'audits'/'color_stability'/'before'
            reference_sources = [np.array(Image.open(path).convert('RGBA')) for path in sorted((reference_pack/'sources').glob('busy_*.png'))]
            rec['color_only_shape_reference'] = str(reference_pack)
            rec['source_alpha_changes_vs_color_only_shape_reference'] = sum(int(np.count_nonzero(a[:,:,3]!=b[:,:,3])) for a,b in zip(source,reference_sources))
            assert rec['source_alpha_changes_vs_color_only_shape_reference'] == 0
            _, reference_native = native_frames(reference_pack/'busy.ani')
            rec['baseline_qualification'] = 'MotionStudy baseline busy outputs preceded the foreleg anatomy revision; current output propagates that existing shared rig.'
        else:
            assert rec['source_alpha_changes_vs_before'] == 0
        for size in (32,48,64):
            for i, frame in enumerate(source):
                prepared = np.array(Image.fromarray(frame).resize((size,size),Image.Resampling.LANCZOS))
                prepared[:,:,3] = np.where(prepared[:,:,3]>=128,255,0)
                embedded, point = resources[i][size]
                assert np.array_equal(prepared[:,:,3],embedded[:,:,3])
                visible=prepared[:,:,3]==255
                assert np.array_equal(prepared[:,:,:3][visible],embedded[:,:,:3][visible])
            info, data = native[str(size)]
            px, py = info['hotspot']
            assert info['width'] == size and info['height'] == size
            assert all(frame[py,px,3] == 255 for frame in data)
            assert len({frame[py,px].tobytes() for frame in data}) == 1
            assert all(not any((f[0,:,3].any(),f[-1,:,3].any(),f[:,0,3].any(),f[:,-1,3].any())) for f in data)
            gif_path = pack/'native_transparent_previews'/f'{role}_{size}px.gif'
            decoded, delays = frames(gif_path)
            assert len(decoded) == len(data)
            assert abs(sum(delays)-metadata['loop_ms']) < .1
            assert set(delays) <= {30,40}
            assert all(np.array_equal(a[:,:,3],b[:,:,3]) for a,b in zip(data,decoded))
            stable = fixed_color_metrics(data, decoded)
            assert stable['gif_flickering_fixed_pixels'] == 0
            with Image.open(baseline/'native_transparent_previews'/f'{role}_{size}px.gif') as previous:
                old_decoded = [np.array(f.convert('RGBA')) for f in ImageSequence.Iterator(previous)]
            prior_info, prior_data = before_native[str(size)]
            previous_stable = fixed_color_metrics(prior_data,old_decoded)
            native_alpha_changes = sum(int(np.count_nonzero(a[:,:,3]!=b[:,:,3])) for a,b in zip(data,prior_data))
            _, reference_data = reference_native[str(size)]
            reference_alpha_changes = sum(int(np.count_nonzero(a[:,:,3]!=b[:,:,3])) for a,b in zip(data,reference_data))
            assert reference_alpha_changes == 0
            fixed_patch = np.stack(data)[:,max(0,py-2):py+3,max(0,px-2):px+3]
            patch_variation = int(np.count_nonzero(np.any(fixed_patch != fixed_patch[0], axis=(0,3))))
            # The 5x5 patch is authored at 64px. Scaled smaller resources can
            # blend neighboring moving pixels, so only the click pixel is required fixed.
            if size == 64: assert patch_variation == 0
            quant_error = max(int(np.abs(a[:,:,:3].astype(int)-b[:,:,:3]).max(axis=2)[a[:,:,3]==255].max()) for a,b in zip(data,decoded))
            if size == 64:
                assert all(np.array_equal(a[:,:,:3][a[:,:,3]==255],b[:,:,:3][a[:,:,3]==255]) for a,b in zip(data,source))
            rec['sizes'][str(size)] = dict(native_info=info, frames_loaded_and_forced=len(data), binary_effective_opacity=True,
                embedded_resources_match_resized_sources=True, native_edge_pixels=0, fixed_opaque_contact=True,
                source_fidelity_verified=(size==64), gif_masks_exact=True, gif_loop_ms=sum(delays),
                gif_delays_ms=delays, gif_maximum_rgb_quantization_error=quant_error,
                fixed_color=stable, baseline_fixed_color=previous_stable, native_alpha_changes_vs_before=native_alpha_changes,
                native_alpha_changes_vs_color_only_shape_reference=reference_alpha_changes,
                adjacent_transitions=changes(data), five_by_five_native_contact_patch_changed_pixels=patch_variation)
            if size in (32,64): sheet(data,out/f'{role}_native{size}_audit.png',size)
        report['roles'][role] = rec
    html = (pack/'preview.html').read_text(encoding='utf-8')
    images = re.findall(r'<img src="([^"]+)" width="(\d+)" height="(\d+)"[^>]*>',html)
    assert len(images) == 9
    for path,w,h in images:
        assert (pack/path).is_file()
        with Image.open(pack/path) as im:
            assert im.width == im.height
            assert (int(w),int(h)) in ((im.width,im.height),(im.width*2,im.height*2))
    assert 'banner' not in html.lower()
    if 'Stomp' in pack.name:
        assert 'a stomping Horseman for links' in html and 'a pointing gauntlet for links' not in html
    report['preview_static_checks'] = dict(referenced_animated_images=images, no_obsolete_banner=True,
        sizes_native32_native64_inspection128=True, image_rendering_pixelated_on_inspection=True,
        static_browser_cursor_contact_only=True, browser_wall_clock_timing_measured=False)
    report['scheme_matches_audit_start'] = scheme_state() == initial_scheme
    report['scheme_matches_preserved_baseline'] = scheme_state() == json.loads((baseline/'scheme_state.json').read_text())
    assert report['scheme_matches_audit_start'] and report['scheme_matches_preserved_baseline']
    report['limitations'] = ['All native frame tests force DrawIconEx indices; automatic playback was not measured.',
        'Source illustrations are still pieces; composites are rigged and periodic effects, not independently drawn source poses.',
        'Flame/tail deformations are procedural image warps, not physical simulation.',
        'No cursor was equipped and no native trial window was opened.',
        'Live browser control and timing are handled separately by the parent agent.']
    (out/'measurements.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(dict(pack=pack.name,identity_matches=report['identity_matches'],roles={role:{size:{'fixed_color':rec['fixed_color'], 'baseline_fixed_color':rec['baseline_fixed_color'], 'gif_loop_ms':rec['gif_loop_ms'], 'gif_maximum_rgb_quantization_error':rec['gif_maximum_rgb_quantization_error']} for size,rec in record['sizes'].items()} for role,record in report['roles'].items()},scheme_unchanged=report['scheme_matches_audit_start']),indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('pack',type=Path)
    main(parser.parse_args().pack.resolve())
