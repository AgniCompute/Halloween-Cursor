"""Read delivered GIF blocks and pixels; write supplemental audit evidence."""
import argparse
import hashlib
import json
import shutil
import struct
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageSequence

ROOT=Path(__file__).resolve().parents[5]
sys.path.insert(0,str(ROOT))
from engine.preview_gen import gif_palette_frames


def sha(data): return hashlib.sha256(data).hexdigest()


def gif_blocks(path):
    raw=path.read_bytes()
    assert raw[:6] in (b'GIF89a',b'GIF87a')
    width,height,packed=struct.unpack_from('<HHB',raw,6)
    offset=13
    palette=None
    if packed&128:
        count=3*2**((packed&7)+1)
        palette=raw[offset:offset+count];offset+=count
    images,controls,palettes=[],[],[]
    def skip_blocks(pos):
        while raw[pos]:pos+=1+raw[pos]
        return pos+1
    while raw[offset]!=0x3b:
        tag=raw[offset];offset+=1
        if tag==0x21:
            label=raw[offset];offset+=1
            if label==0xf9:
                assert raw[offset]==4
                fields=raw[offset+1:offset+5]
                flags,delay,transparent=struct.unpack('<BHB',fields)
                controls.append(dict(disposal=(flags>>2)&7,transparency=bool(flags&1),transparent_index=transparent,duration_ms=delay*10))
            offset=skip_blocks(offset)
        elif tag==0x2c:
            left,top,w,h,flags=struct.unpack_from('<4HB',raw,offset);offset+=9
            current_palette=palette
            if flags&128:
                count=3*2**((flags&7)+1)
                current_palette=raw[offset:offset+count];offset+=count
            palettes.append(sha(current_palette))
            images.append([left,top,w,h])
            offset+=1
            offset=skip_blocks(offset)
        else:raise AssertionError((path,tag,offset))
    assert offset+1==len(raw)
    return dict(dimensions=[width,height],image_blocks=len(images),unique_palette_tables=len(set(palettes)),
        palette_hashes=sorted(set(palettes)), graphic_controls=controls,frame_rectangles=images)


def rgba_frames(path):
    with Image.open(path) as im:
        return [np.array(f.convert('RGBA')) for f in ImageSequence.Iterator(im)], [f.info.get('duration') for f in ImageSequence.Iterator(im)]


def main(pack):
    out=pack/'audits'/'color_stability'/'round1'
    identity=json.loads((pack/'build_identity.json').read_text())
    names=[name for name in identity['preview_files'] if name.endswith('.gif')]+['review.gif']
    if (pack/'stomp-rich-color.gif').is_file():names.append('stomp-rich-color.gif')
    report={}
    for name in names:
        record=gif_blocks(pack/name)
        data,delays=rgba_frames(pack/name)
        assert record['image_blocks']==len(data)==len(delays)
        assert all(g['disposal']==2 and g['transparency'] and g['transparent_index']==0 for g in record['graphic_controls'])
        assert set(delays)<= {30,40}
        role=name.split('/')[-1].split('_')[0].split('.')[0]
        expected=800 if role=='busy' else 1600
        assert sum(delays)==expected
        record['decoded_frames']=len(data)
        record['loop_ms']=sum(delays)
        if name!='stomp-rich-color.gif': assert record['unique_palette_tables']==1
        arr=np.stack(data)
        # Repeated palette conversion must not flicker fixed outlines or labels.
        # GIF-only invariance is independently measured against native/source in audit_color.
        record['binary_alpha']=set(arr[:,:,:,3].ravel())<= {0,255}
        assert record['binary_alpha']
        if name.startswith('native_previews/'):
            assert np.all(arr[:,:,:,3]==255)
        if name=='stomp-rich-color.gif':
            native,native_delays=rgba_frames(pack/'native_transparent_previews'/'link_64px.gif')
            assert delays==native_delays
            for actual,source in zip(data,native):
                expected_frame=np.array(Image.fromarray(source).resize((128,128),Image.Resampling.NEAREST))
                assert np.array_equal(actual[:,:,3],expected_frame[:,:,3])
                visible=actual[:,:,3]==255
                assert np.array_equal(actual[:,:,:3][visible],expected_frame[:,:,:3][visible])
            record['nearest_2x_visible_RGB_and_masks_lossless']=True
            record['palette_note']='Per-frame index remapping is lossless to the single-palette native GIF; no second quantizer.'
        report[name]=record
    # Opaque-sample palette excludes hidden colors. Compare two otherwise
    # identical inputs whose clear RGB values differ.
    a=np.zeros((8,8,4),np.uint8);a[:4,:,:]=[100,35,165,255]
    b=a.copy();b[4:,:,:3]=[0,255,0]
    p1=gif_palette_frames([Image.fromarray(a)])[0]
    p2=gif_palette_frames([Image.fromarray(b)])[0]
    assert p1.getpalette()==p2.getpalette()
    assert np.array_equal(np.array(p1),np.array(p2))
    report['hidden_color_invariance_probe']=True
    # Visually review the unmodified, generated still pieces used by both horses.
    panel=Image.new('RGB',(700,460),'#f1ece4');d=ImageDraw.Draw(panel)
    for index,name in enumerate(('body','cape','tail','front_upper','rear_upper','shin')):
        im=Image.open(pack/'source_art'/f'{name}.png').convert('RGBA')
        bounds=im.getchannel('A').getbbox()
        im=im.crop(bounds);im.thumbnail((205,190),Image.Resampling.LANCZOS)
        x,y=(index%3)*233,(index//3)*230
        panel.paste(im,(x+10,y+28),im);d.text((x+10,y+6),f'{name}: one still piece',fill='#402344')
    panel.save(out/'source_pieces_audit.png')
    # Load exact copies with the delivered helper, keeping its status file in
    # the audit directory and preserving read-only production output.
    trial=out/'trial_load';trial.mkdir(exist_ok=True)
    for name in ('try_horseman_motion_study.py','animation_manifest.json','pointer.ani','link.ani','busy.ani'):
        shutil.copy2(pack/name,trial/name)
    result=subprocess.run([sys.executable,str(trial/'try_horseman_motion_study.py'),'--pack',str(trial),'--check-load'],capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    status=json.loads((trial/'trial_status.json').read_text())
    assert status['window_created'] is False and status['scheme_changed'] is False
    assert status['files']== {role:identity['files'][f'{role}.ani'] for role in ('pointer','link','busy')}
    report['packaged_helper_check_load']=dict(exact_copies_loaded=True,window_created=False,
        scope='32px and64px LoadImageW only; no automatic playback or aiming assertion',status=status)
    (out/'gif_checks.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(dict(pack=pack.name,gif_files_checked=len(names),shared_palette_checks=True,
        inspection_lossless=report.get('stomp-rich-color.gif',{}).get('nearest_2x_visible_RGB_and_masks_lossless'),
        packaged_helper_check_load=True),indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('pack',type=Path)
    main(parser.parse_args().pack.resolve())
