"""Observe the study's ANI cursors in one temporary Windows window.

LoadImageW and SetCursor apply only to this window. This helper does not install
the study, write the registry, or change the user's cursor scheme. Its status
file records a successful load/window launch, not an animation-quality result.
"""
import argparse
import ctypes as c
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PACK = ROOT / "cursor_sets" / "HorsemanMotionStudy"
if not PACK.is_dir() and (ROOT / "pointer.ani").is_file():
    PACK = ROOT  # The same helper also works inside an extracted study ZIP.
ROLES = ("pointer", "link", "busy")
STATUS = PACK / "trial_status.json"
WM_PAINT, WM_DESTROY, WM_SETCURSOR, WM_KEYDOWN = 0x0F, 2, 0x20, 0x100
HTCLIENT = 1


def region_index(x, width):
    """Use the same integer boundaries as the three painted panels."""
    if width <= 0:
        return 0
    return min(2, max(0, (3 * x + 2) // width))


def main(check_load=False, pack=None):
    global PACK, STATUS
    if pack is not None:
        PACK = Path(pack).resolve()
        STATUS = PACK / 'trial_status.json'
    manifest = json.loads((PACK / 'animation_manifest.json').read_text(encoding='utf-8'))
    is_stomp = 'stomp' in next(item['title'] for item in manifest if item['role'] == 'link').lower()
    trial_title = 'Horseman stomp study' if is_stomp else 'Horseman motion study'
    u = c.WinDLL("user32", use_last_error=True)
    g = c.WinDLL("gdi32", use_last_error=True)
    k = c.WinDLL("kernel32", use_last_error=True)
    result_type = c.c_ssize_t
    proc_type = c.WINFUNCTYPE(result_type, w.HWND, w.UINT, w.WPARAM, w.LPARAM)

    class WindowClass(c.Structure):
        _fields_ = [("style", w.UINT), ("proc", proc_type), ("extra", c.c_int),
                    ("window_extra", c.c_int), ("instance", w.HINSTANCE),
                    ("icon", w.HICON), ("cursor", w.HANDLE),
                    ("background", w.HBRUSH), ("menu", w.LPCWSTR),
                    ("name", w.LPCWSTR)]

    class Paint(c.Structure):
        _fields_ = [("dc", w.HDC), ("erase", w.BOOL), ("rect", w.RECT),
                    ("restore", w.BOOL), ("update", w.BOOL),
                    ("reserved", c.c_byte * 32)]

    class IconInfo(c.Structure):
        _fields_ = [("is_icon", w.BOOL), ("hotspot_x", w.DWORD),
                    ("hotspot_y", w.DWORD), ("mask", w.HBITMAP),
                    ("color", w.HBITMAP)]

    class Bitmap(c.Structure):
        _fields_ = [("type", w.LONG), ("width", w.LONG), ("height", w.LONG),
                    ("width_bytes", w.LONG), ("planes", w.WORD),
                    ("bits_pixel", w.WORD), ("bits", c.c_void_p)]

    u.DefWindowProcW.argtypes = [w.HWND, w.UINT, w.WPARAM, w.LPARAM]
    u.DefWindowProcW.restype = result_type
    u.RegisterClassW.argtypes = [c.POINTER(WindowClass)]
    u.RegisterClassW.restype = w.WORD
    u.UnregisterClassW.argtypes = [w.LPCWSTR, w.HINSTANCE]
    u.UnregisterClassW.restype = w.BOOL
    u.CreateWindowExW.argtypes = [w.DWORD, w.LPCWSTR, w.LPCWSTR, w.DWORD,
                                 c.c_int, c.c_int, c.c_int, c.c_int,
                                 w.HWND, w.HMENU, w.HINSTANCE, c.c_void_p]
    u.CreateWindowExW.restype = w.HWND
    u.LoadImageW.argtypes = [w.HINSTANCE, w.LPCWSTR, w.UINT,
                            c.c_int, c.c_int, w.UINT]
    u.LoadImageW.restype = w.HANDLE
    u.SetCursor.argtypes = [w.HANDLE]
    u.SetCursor.restype = w.HANDLE
    u.DestroyCursor.argtypes = [w.HANDLE]
    u.DestroyCursor.restype = w.BOOL
    u.GetIconInfo.argtypes = [w.HANDLE, c.POINTER(IconInfo)]
    u.GetIconInfo.restype = w.BOOL
    u.BeginPaint.argtypes = [w.HWND, c.POINTER(Paint)]
    u.BeginPaint.restype = w.HDC
    u.EndPaint.argtypes = [w.HWND, c.POINTER(Paint)]
    u.GetClientRect.argtypes = [w.HWND, c.POINTER(w.RECT)]
    u.GetCursorPos.argtypes = [c.POINTER(w.POINT)]
    u.ScreenToClient.argtypes = [w.HWND, c.POINTER(w.POINT)]
    u.FillRect.argtypes = [w.HDC, c.POINTER(w.RECT), w.HBRUSH]
    u.DrawTextW.argtypes = [w.HDC, w.LPCWSTR, c.c_int, c.POINTER(w.RECT), w.UINT]
    u.ShowWindow.argtypes = [w.HWND, c.c_int]
    u.UpdateWindow.argtypes = [w.HWND]
    u.DestroyWindow.argtypes = [w.HWND]
    u.InvalidateRect.argtypes = [w.HWND, c.POINTER(w.RECT), w.BOOL]
    u.PostQuitMessage.argtypes = [c.c_int]
    u.GetMessageW.argtypes = [c.POINTER(w.MSG), w.HWND, w.UINT, w.UINT]
    u.GetMessageW.restype = c.c_int
    u.TranslateMessage.argtypes = [c.POINTER(w.MSG)]
    u.DispatchMessageW.argtypes = [c.POINTER(w.MSG)]
    u.DispatchMessageW.restype = result_type
    g.CreateSolidBrush.argtypes = [w.DWORD]
    g.CreateSolidBrush.restype = w.HBRUSH
    g.DeleteObject.argtypes = [w.HANDLE]
    g.GetObjectW.argtypes = [w.HANDLE, c.c_int, c.c_void_p]
    g.GetObjectW.restype = c.c_int
    g.SetTextColor.argtypes = [w.HDC, w.DWORD]
    g.SetBkMode.argtypes = [w.HDC, c.c_int]
    k.GetModuleHandleW.argtypes = [w.LPCWSTR]
    k.GetModuleHandleW.restype = w.HINSTANCE

    cursors = []
    size = 32
    window = None
    load_history = []
    error = None
    window_created = False

    def native_info(handle):
        info, bitmap = IconInfo(), Bitmap()
        if not u.GetIconInfo(handle, c.byref(info)):
            raise c.WinError(c.get_last_error())
        try:
            bitmap_handle = info.color or info.mask
            if not g.GetObjectW(bitmap_handle, c.sizeof(bitmap), c.byref(bitmap)):
                raise c.WinError(c.get_last_error())
            return {"width": bitmap.width,
                    "height": bitmap.height if info.color else bitmap.height // 2,
                    "hotspot": [info.hotspot_x, info.hotspot_y]}
        finally:
            if info.mask:
                g.DeleteObject(info.mask)
            if info.color:
                g.DeleteObject(info.color)

    def hashes():
        return {role: hashlib.sha256((PACK / f"{role}.ani").read_bytes()).hexdigest()
                for role in ROLES if (PACK / f"{role}.ani").is_file()}

    def save_status(closed=False):
        STATUS.write_text(json.dumps({
            "pack": str(PACK), "pid": os.getpid(),
            "window_created": window_created, "window_closed": closed,
            "hwnd": int(window) if window else None,
            "loaded_size": size if cursors else None,
            "load_history": load_history, "files": hashes(),
            "loader": "LoadImageW disk, IMAGE_CURSOR, LR_LOADFROMFILE",
            "cursor_scope": "temporary trial window client area",
            "scheme_changed": False, "automatic_playback_verified": False,
            "motion_quality_verified": False, "error": error,
        }, indent=2), encoding="utf-8")

    def load_size(value):
        nonlocal cursors, size
        fresh, details = [], {}
        try:
            for role in ROLES:
                handle = u.LoadImageW(None, str(PACK / f"{role}.ani"),
                                      2, value, value, 0x10)
                if not handle:
                    raise c.WinError(c.get_last_error())
                fresh.append(handle)
                details[role] = native_info(handle)
        except Exception:
            for handle in fresh:
                u.DestroyCursor(handle)
            raise
        previous = cursors
        cursors, size = fresh, value
        load_history.append({"size": value, "files": hashes(),
                             "roles_loaded": list(ROLES), "native": details})
        if window:
            use_cursor(window)
        for handle in previous:
            u.DestroyCursor(handle)

    def use_cursor(hwnd):
        point, rect = w.POINT(), w.RECT()
        if not u.GetCursorPos(c.byref(point)):
            return
        if not u.ScreenToClient(hwnd, c.byref(point)):
            return
        if not u.GetClientRect(hwnd, c.byref(rect)):
            return
        if 0 <= point.x < rect.right and 0 <= point.y < rect.bottom:
            u.SetCursor(cursors[region_index(point.x, rect.right)])

    @proc_type
    def callback(hwnd, message, wp, lp):
        nonlocal error
        if message == WM_SETCURSOR and (lp & 0xFFFF) == HTCLIENT:
            use_cursor(hwnd)
            return 1
        if message == WM_KEYDOWN:
            if wp == 27:
                u.DestroyWindow(hwnd)
            elif wp in (ord("1"), ord("2")):
                try:
                    load_size(32 if wp == ord("1") else 64)
                    error = None
                except Exception as exc:
                    error = str(exc)
                save_status()
                u.InvalidateRect(hwnd, None, True)
            return 0
        if message == WM_PAINT:
            ps, rect = Paint(), w.RECT()
            dc = u.BeginPaint(hwnd, c.byref(ps))
            u.GetClientRect(hwnd, c.byref(rect))
            g.SetBkMode(dc, 1)
            panels = (
                (0x292124, 0xFFFFFF, "EMBER ARROW\n\nMove your mouse here.\nThe point stays still while the flame\nand ribbon sway."),
                (0x392A33, 0xFFFFFF,
                 "EMBER STOMP\n\nMove your mouse here.\nWatch the hoof lift, pause and strike.\nThe gold pulse repeats with the loop."
                 if is_stomp else "POINTING HAND\n\nMove your mouse here.\nThe fingertip stays still while the\ncuff flame and ribbon move."),
                (0xE8EDF2, 0x242020, "HORSEMAN GALLOP\n\nMove your mouse here.\nWatch the legs, cape and flame tail\nthrough a complete loop."),
            )
            for index, (background, foreground, text) in enumerate(panels):
                left, right = index * rect.right // 3, (index + 1) * rect.right // 3
                box = w.RECT(left, 0, right, rect.bottom)
                brush = g.CreateSolidBrush(background)
                u.FillRect(dc, c.byref(box), brush)
                g.DeleteObject(brush)
                g.SetTextColor(dc, foreground)
                box = w.RECT(left + 20, 80, right - 20, max(100, rect.bottom - 105))
                u.DrawTextW(dc, text, -1, c.byref(box), 0x10 | 1)
            # Paint the instructions on their own strip so all text has one
            # clear background, independent of which cursor panel is active.
            footer = w.RECT(0, max(0, rect.bottom - 95), rect.right, rect.bottom)
            brush = g.CreateSolidBrush(0x181818)
            u.FillRect(dc, c.byref(footer), brush)
            g.DeleteObject(brush)
            g.SetTextColor(dc, 0xFFFFFF)
            footer = w.RECT(12, max(0, rect.bottom - 82), rect.right - 12, rect.bottom - 8)
            text = (f"{trial_title} · {size}px\n"
                    "1: 32px   2: 64px   Esc: close\n"
                    "These cursors apply only inside this window.")
            if error:
                text += f"\nCould not load that size: {error}"
            u.DrawTextW(dc, text, -1, c.byref(footer), 0x10 | 1)
            u.EndPaint(hwnd, c.byref(ps))
            return 0
        if message == WM_DESTROY:
            u.PostQuitMessage(0)
            return 0
        return u.DefWindowProcW(hwnd, message, wp, lp)

    instance = k.GetModuleHandleW(None)
    class_name = f"HorsemanMotionStudyTrial_{os.getpid()}"
    registered = False
    try:
        load_size(32)
        if check_load:
            load_size(64)
            save_status()
            print(f"Loaded pointer, link and busy ANI files at 32 and 64 px. No window opened.\nStatus: {STATUS}")
            return
        wc = WindowClass(3, callback, 0, 0, instance, None, None, None, None, class_name)
        if not u.RegisterClassW(c.byref(wc)):
            raise c.WinError(c.get_last_error())
        registered = True
        window = u.CreateWindowExW(0, class_name, trial_title, 0x00CF0000,
                                    160, 120, 1080, 520, None, None, instance, None)
        if not window:
            raise c.WinError(c.get_last_error())
        window_created = True
        u.ShowWindow(window, 5)
        # STARTUPINFO from a hidden launcher can override the first ShowWindow.
        u.ShowWindow(window, 5)
        u.UpdateWindow(window)
        save_status()
        message = w.MSG()
        while True:
            result = u.GetMessageW(c.byref(message), None, 0, 0)
            if result == -1:
                raise c.WinError(c.get_last_error())
            if result == 0:
                break
            u.TranslateMessage(c.byref(message))
            u.DispatchMessageW(c.byref(message))
    except Exception as exc:
        error = str(exc)
        save_status()
        raise
    finally:
        if window_created:
            save_status(closed=True)
        for handle in cursors:
            u.DestroyCursor(handle)
        if registered:
            u.UnregisterClassW(class_name, instance)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-load", action="store_true",
                        help="load the three ANI files at both sizes without opening a window")
    parser.add_argument('--pack', type=Path,
                        help='trial this pack folder instead of the default MotionStudy')
    args = parser.parse_args()
    main(check_load=args.check_load, pack=args.pack)
