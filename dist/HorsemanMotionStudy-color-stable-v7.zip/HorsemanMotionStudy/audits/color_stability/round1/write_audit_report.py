"""Write the independent audit report and bind acceptance to reviewed bytes."""
import hashlib
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[5]


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main(name):
    pack=ROOT/'cursor_sets'/name
    out=pack/'audits'/'color_stability'/'round1'
    measurements=json.loads((out/'measurements.json').read_text())
    gifs=json.loads((out/'gif_checks.json').read_text())
    identity=json.loads((pack/'build_identity.json').read_text())
    assert identity['files']==measurements['exact_hashes']['files']
    assert identity['implementation_files']==measurements['exact_hashes']['implementation_files']
    for relative,expected in measurements['exact_hashes']['artifacts'].items():
        assert sha(pack/relative)==expected,relative
    artifacts={}
    top=['pointer.ani','link.ani','busy.ani','README.txt','preview.html','review.gif',
        'animation_manifest.json','build_identity.json','validation.json','muse_native_validation.json',
        'windows_render_check.png','windows_render_check_32px.png','windows_render_check_64px.png',
        'native_backgrounds_32px.png','native_backgrounds_64px.png','source_contact.png',
        'try_horseman_motion_study.py']+list(identity['trial_files'])
    if 'Stomp' in name:top.append('stomp-rich-color.gif')
    for relative in sorted(set(top)):
        artifacts[relative]=sha(pack/relative)
    for folder in ('sources','source_art','previews','embedded_previews','native_previews','native_transparent_previews','browser_cursors'):
        for path in sorted((pack/folder).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc':
                artifacts[path.relative_to(pack).as_posix()]=sha(path)
    for relative,expected in measurements['exact_hashes']['composite_sources'].items():
        assert artifacts[relative]==expected
    for relative,expected in identity['source_files'].items():
        assert artifacts['source_art/'+Path(relative).name]==expected
    for bucket in ('files','preview_files','validation_files','trial_files'):
        for relative,expected in identity[bucket].items():
            assert artifacts[relative]==expected
    evidence={}
    for relative in ('browser_checks.json','browser_preview.png','color_stability_checks.json'):
        path=pack/'audits'/'color_stability'/relative
        evidence[path.relative_to(pack).as_posix()]=sha(path)
    browser=json.loads((pack/'audits'/'color_stability'/'browser_checks.json').read_text())
    assert browser['wallClockTimingMeasured'] is False
    for record in browser['images']['images']:
        assert record['complete'] and record['opacity']=='1' and record['filter']=='none'
        assert record['display'] in ([32,32],[64,64],[128,128])
        if record['display']==[128,128]:assert record['sampling']=='pixelated'
    accepted=dict(accepted=True,high_severity_actionable_findings=[],files=measurements['exact_hashes']['files'],
        build_identity_sha256=measurements['exact_hashes']['artifacts']['build_identity.json'],
        preview_sha256=measurements['exact_hashes']['artifacts']['preview.html'],
        manifest_sha256=measurements['exact_hashes']['artifacts']['animation_manifest.json'],
        implementation_files=measurements['exact_hashes']['implementation_files'],
        artifact_files=artifacts,evidence_files=evidence,
        art_version=identity['art_version'],audit_round=1,
        audit_scope='Three delivered proof roles, source grading, native forced-index frames/resources, GIF stability/masks/stored timing, preview layout and supplied browser evidence',
        automatic_equipped_playback_verified=False,automatic_window_playback_verified=False,
        browser_wall_clock_timing_measured=False,fluid_character_motion_verified=False,
        scheme_changed=False)
    title='Horseman Stomp Study' if 'Stomp' in name else 'Horseman Motion Study'
    parts=[f'# Independent audit: {title}\n',
        f'**Verdict: accepted, round 1.** No high-severity actionable artwork, motion, encoding, or preview findings remain for `{identity["art_version"]}`. This acceptance covers the three proof roles (pointer, link, busy). It does not approve equipping a cursor or certify automatic playback.\n',
        '## What was independently tested\n',
        '- Loaded each delivered ANI from disk with Windows `LoadImageW` at 32, 48, and 64 pixels. Forced every `DrawIconEx` index on black and white: 120 indices per size, 360 native frame pairs per pack. Recovered RGBA from the black/white difference and saved all native frames under `native/`.\n'
        '- Parsed every ANI RIFF/CUR/DIB resource: 24-bit BGR and one-bit AND masks at 32/48/64. Compared visible RGB and masks of all 360 embedded resources against the resized, alpha-thresholded delivered source composites. Native 64px visible pixels exactly match the delivered source composites. The native32 disk-loader result is reviewed as delivered; selection of the separately prepared embedded32 resource is not assumed.\n'
        '- Checked every native frame for binary effective opacity, opaque/fixed click pixel and empty canvas edges. All pass at all three sizes. The authored 5x5 saddle patch is invariant at native64; at smaller sizes only the click pixel, rather than a rescaled 5x5 neighborhood, is required to remain fixed.\n'
        '- Compared all native transparent GIF masks to fresh native renders. All masks match exactly. Tested every native invariant opaque pixel for color flicker against fresh renders and the preserved pre-turn baseline. Current flickering invariant-pixel count and channel span are zero for every role/size.\n'
        '- Parsed all current GIF block tables, disposal/transparency controls and stored delays. Each quantized animation has one shared palette, no per-frame palette drift, disposal=2, transparent index zero, and binary decoded alpha. A separate hidden-RGB probe confirms clear pixels do not affect the selected palette.\n'
        '- Checked the shared source grading: all six still-piece alpha channels are unchanged by `rich_materials`; loader grading is the same fixed operation for both horses before resizing/deformation. Delivered still pieces match original assets. Pointer and hand illustrations are not accidentally horse-graded.\n'
        '- Ran the delivered trial helper with `--check-load` on exact copies under `trial_load/`. It loaded all three ANI files at32 and64, created no window, and changed no scheme. This proves loading only.\n'
        '- Verified all identity/source/implementation/preview/trial/validation hashes, and measured every release artifact in `audit_acceptance.json`. Registry cursor/mouse/accessibility values equal both audit-start values and the preserved baseline.\n',
        '## Visual and implementation review\n',
        'Viewed the actual native 32px and64px contact sheets and new audit grids for every index, source composite contact sheets, six generated still pieces, current HTML screenshot, and current GIF frame data. The rigid arrow retains aligned head/shaft and its contact point. '+
        ('The link horse shows a lift, held raised pose, return/strike and ground pulse; the pulse is a looping effect independent of mouse clicks. ' if 'Stomp' in name else 'The pointing gauntlet keeps a readable index/hand silhouette with stationary fingertip and animated cuff ornaments. ')+
        'The shared gallop has attached, substantial forelegs and a continuous torso/shoulder mass through support and recovery. Far legs retain intentional depth shading. Flame tail, cape and cuff/heel flame roots remain attached in the reviewed composites; no canvas clipping was found. Horse muzzle/ear/tack and pumpkin accents remain readable at64px; fine face/trim detail collapses to very few pixels at32px. This is a retained resolution limit, rather than newly drawn facial acting.\n',
        'The six horse PNG pieces each contain one generated still illustration. The delivered 24-frame gallop and48-frame stomp are kinematic rig composites using those pieces; pointer and hand use one still source each with isolated ornaments and periodic image warps. These are not independently drawn source poses, and flame motion is not physical simulation.\n',
        'Measured wrap transitions fall within ordinary adjacent-frame channel-delta ranges. For the shared gallop at64px the seam changes1216 pixels versus an ordinary adjacent mean1192.3; seam mean RGBA-channel delta6.35 versus maximum ordinary7.56. These pixel measures and pose-grid inspection did not reveal a special wrap jump. They do not prove fluid character motion or human-perceived cadence.\n',
        '## Color and stored timing results\n',
        '| Role | Native invariant opaque pixels, 32/48/64 | Baseline GIF flicker count, 32/48/64 | Current GIF flicker count | ANI/GIF loop |\n|---|---:|---:|---:|---:|\n']
    for role,record in measurements['roles'].items():
        sizes=[record['sizes'][str(s)] for s in (32,48,64)]
        invariant='/'.join(str(v['fixed_color']['native_fixed_opaque_pixels']) for v in sizes)
        old='/'.join(str(v['baseline_fixed_color']['gif_flickering_fixed_pixels']) for v in sizes)
        parts.append(f'| {role} | {invariant} | {old} | 0/0/0 | {record["metadata"]["loop_ms"]:.0f} ms |\n')
    parts.append('\nNative ANI timing remains2 jiffies per frame (nominal30fps). GIF delays alternate the necessary30/40ms centisecond values without changing total loop length: pointer/link1600ms, busy800ms. The combined review is1600ms with the busy loop repeated twice. Browser wall-clock timing was not measured. GIF palettes remain lossy to native true color: see per-size maximum quantization differences in `measurements.json`; stability does not mean pixel-identical RGB.\n')
    if 'Stomp' in name:
        parts.append('The current2x `stomp-rich-color.gif` was independently decoded and compared with the nearest enlargement of `native_transparent_previews/link_64px.gif`: every visible RGB pixel, mask and delay is exact. Its per-frame palette-index remapping is lossless and adds no second quantization. All native/source alpha masks match the pre-turn Stomp baseline.\n')
    else:
        parts.append('The MotionStudy busy baseline on disk lagged an already-authored foreleg anatomy revision: current versus its own baseline changes535 source/native64 alpha pixels over the full24-frame cycle (native32:133, native48:293). This is propagation of the existing shared rig. The color-only control is StompStudy `audits/color_stability/before/busy.ani` and its source frames: native/source mask changes are zero at32/48/64 against that reference. Current busy ANI bytes are identical in the two packs. Pointer and hand masks also match MotionStudy\'s own baseline.\n')
    parts.extend(['## Browser preview review\n',
        'The auditor reviewed the HTML/CSS/JavaScript, referenced GIF dimensions and supplied live-browser JSON/screenshot evidence. The parent agent operated the live browser. All nine images load at native32/native64 and labelled128px nearest inspection; CSS opacity is1 and filters are absent at DPR1. '+
        ('Live evidence covers all five backgrounds, contact toggle, three role selections and a semantic target-click count change. The automated count check does not establish human aiming accuracy. ' if 'Stomp' in name else 'Live MotionStudy evidence covers image sizes/styles and White background; full toolbar/control behavior was exercised on the shared Stomp preview implementation. ')+
        'Descriptions match the current arrow/'+('stomp' if 'Stomp' in name else 'hand')+'/gallop art and there is no obsolete banner. The target pad correctly uses a static native32 PNG and does not claim browser ANI playback. Browser wall-clock cadence remains unmeasured.\n',
        '## Exact accepted bytes\n',
        '| Delivered ANI | SHA256 |\n|---|---|\n'])
    for relative,hash_value in accepted['files'].items():parts.append(f'| {relative} | `{hash_value}` |\n')
    parts.append('\n| Binding | SHA256 |\n|---|---|\n')
    for relative in ('build_identity.json','preview.html','animation_manifest.json','review.gif'):
        parts.append(f'| {relative} | `{artifacts[relative]}` |\n')
    if 'Stomp' in name:parts.append(f'| stomp-rich-color.gif | `{artifacts["stomp-rich-color.gif"]}` |\n')
    parts.append('\n| Reviewed implementation | SHA256 |\n|---|---|\n')
    for relative,hash_value in accepted['implementation_files'].items():parts.append(f'| {relative} | `{hash_value}` |\n')
    parts.append('\nAll source composites, copied original sources, previews, validation records, native sheets, README and packaged trial files are individually bound by `artifact_files` in `audit_acceptance.json`. Supplied browser/color evidence is individually bound by `evidence_files`. The detailed actual-native measurements and scripts are retained beside this report.\n')
    parts.append('## Findings and limits\n\nNo P0/P1 artwork, motion, encoding, or preview findings remain. No rebuild was needed after independent review. Remaining disclosed limits are dense face/trim detail at32px, GIF palette color loss, unmeasured browser wall-clock cadence, unverified automatic window/equipped playback, unverified human aiming accuracy and unverified fluid character motion. No cursor scheme was changed and no native trial window was opened.\n')
    report='\n'.join(parts)
    (out/'AUDIT.md').write_text(report,encoding='utf-8')
    accepted['audit_report_sha256']=sha(out/'AUDIT.md')
    (out/'audit_acceptance.json').write_text(json.dumps(accepted,indent=2),encoding='utf-8')
    print(f'Accepted {name}: {len(artifacts)} artifact hashes and {len(evidence)} evidence hashes.')


if __name__=='__main__':
    main(sys.argv[1])
