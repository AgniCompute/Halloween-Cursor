"""Diagnose delivered cursor color, opacity and timing without equipping it."""
import argparse
import ctypes as c
import hashlib
import json
import shutil
import struct
import winreg
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageSequence

from validate_muse_pack import ani_frame_info, draw_icon, icon_info, riff_chunks

ROOT = Path(__file__).resolve().parent
PACK = ROOT / 'cursor_sets' / 'HorsemanStompStudy'
EVIDENCE = PACK / 'audits' / 'color_density'
BASELINE = EVIDENCE / 'before'
ROLES = ('pointer', 'link', 'busy')


def scheme_state():
    result = {}
    for location in ('Control Panel\\Cursors', 'Control Panel\\Mouse',
                     'Software\\Microsoft\\Accessibility'):
        values = {}
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, location) as key:
                index = 0
                while True:
                    try:
                        name, value, kind = winreg.EnumValue(key, index)
                    except OSError:
                        break
                    values[name] = {'value': value.hex() if isinstance(value, bytes) else value, 'type': kind}
                    index += 1
        except FileNotFoundError:
            pass
        result[location] = values
    return result


def native_apis():
    u, g = c.WinDLL('user32', use_last_error=True), c.WinDLL('gdi32', use_last_error=True)
    u.LoadImageW.argtypes = [c.c_void_p, c.c_wchar_p, c.c_uint, c.c_int, c.c_int, c.c_uint]
    u.LoadImageW.restype = c.c_void_p
    u.DestroyIcon.argtypes = [c.c_void_p]
    u.GetIconInfo.argtypes = [c.c_void_p, c.c_void_p]
    u.GetIconInfo.restype = c.c_bool
    u.DrawIconEx.argtypes = [c.c_void_p, c.c_int, c.c_int, c.c_void_p, c.c_int, c.c_int, c.c_uint, c.c_void_p, c.c_uint]
    u.DrawIconEx.restype = c.c_bool
    u.FillRect.argtypes = [c.c_void_p, c.c_void_p, c.c_void_p]
    g.GetObjectW.argtypes = [c.c_void_p, c.c_int, c.c_void_p]
    g.GetObjectW.restype = c.c_int
    g.DeleteObject.argtypes = [c.c_void_p]
    g.SelectObject.argtypes = [c.c_void_p, c.c_void_p]
    g.SelectObject.restype = c.c_void_p
    g.CreateCompatibleDC.argtypes = [c.c_void_p]
    g.CreateCompatibleDC.restype = c.c_void_p
    g.CreateDIBSection.argtypes = [c.c_void_p, c.c_void_p, c.c_uint, c.POINTER(c.c_void_p), c.c_void_p, c.c_uint]
    g.CreateDIBSection.restype = c.c_void_p
    g.CreateSolidBrush.argtypes = [c.c_uint32]
    g.CreateSolidBrush.restype = c.c_void_p
    g.DeleteDC.argtypes = [c.c_void_p]
    g.GdiFlush.argtypes = []
    return u, g


def snapshot():
    if BASELINE.exists():
        raise RuntimeError('Baseline already exists; do not replace original evidence')
    BASELINE.mkdir(parents=True)
    for name in ('sources', 'native_transparent_previews', 'browser_cursors'):
        shutil.copytree(PACK / name, BASELINE / name)
    for path in PACK.iterdir():
        if path.is_file() and path.suffix in ('.ani', '.json', '.png', '.html', '.gif'):
            shutil.copyfile(path, BASELINE / path.name)
    for name in ('engine/horseman_stomp_study.py', 'engine/horseman_motion_preview.py',
                 'build_horseman_stomp_study.py'):
        destination = BASELINE / 'implementation' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, destination)
    (BASELINE / 'scheme_state.json').write_text(json.dumps(scheme_state(), indent=2), encoding='utf-8')


def metadata(path):
    raw = path.read_bytes()
    count, ticks = ani_frame_info(path)
    rate = None
    for tag, body, size in riff_chunks(raw, 12, len(raw)):
        if tag == b'rate':
            rate = list(struct.unpack_from(f'<{size//4}I', raw, body))
    delays = rate or [ticks] * count
    assert len(delays) == count
    return {'frames': count, 'default_jiffies': ticks, 'step_jiffies': delays,
            'loop_ms': sum(delays)*1000/60, 'nominal_fps': count*60/sum(delays)}


def inspect(folder, target):
    target.mkdir(parents=True, exist_ok=True)
    u, g = native_apis()
    report = {'method': 'Windows disk LoadImageW, every forced DrawIconEx index on black and white',
              'automatic_equipped_playback_verified': False, 'roles': {}}
    for role in ROLES:
        path = folder / f'{role}.ani'
        record = metadata(path)
        record['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        record['sizes'] = {}
        for size in (32, 48, 64):
            handle = u.LoadImageW(None, str(path), 2, size, size, 0x10)
            assert handle, (role, size, 'load')
            info = icon_info(u, g, handle)
            frame_dir = target / f'{role}_native{size}'
            frame_dir.mkdir(exist_ok=True)
            stats, contacts = [], []
            all_pixels = []
            try:
                for step in range(record['frames']):
                    black = np.array(draw_icon(u, g, handle, size, 0, step).convert('RGB'), dtype=np.int16)
                    white = np.array(draw_icon(u, g, handle, size, 0xffffff, step).convert('RGB'), dtype=np.int16)
                    transmission = white-black
                    opaque = np.all(transmission == 0, axis=2)
                    clear = np.all(transmission == 255, axis=2)
                    partial = int(np.count_nonzero(~(opaque | clear)))
                    assert partial == 0, (role, size, step, 'partial opacity', partial)
                    rgba = np.dstack((black.astype(np.uint8), np.where(opaque, 255, 0).astype(np.uint8)))
                    assert not any((opaque[0].any(), opaque[-1].any(), opaque[:, 0].any(), opaque[:, -1].any()))
                    hx, hy = info['hotspot']
                    assert opaque[hy, hx]
                    contacts.append(rgba[hy, hx].tobytes())
                    Image.fromarray(rgba).save(frame_dir / f'{step:02}.png')
                    pixels = black[opaque].astype(float)/255
                    all_pixels.append(pixels)
                    stats.append({'step': step, 'partial_alpha_pixels': partial, 'opaque_pixels': int(opaque.sum())})
            finally:
                u.DestroyIcon(handle)
            assert len(set(contacts)) == 1
            pixels = np.concatenate(all_pixels)
            luminance = pixels @ np.array([.2126, .7152, .0722])
            maximum, minimum = pixels.max(axis=1), pixels.min(axis=1)
            saturation = np.divide(maximum-minimum, maximum, out=np.zeros_like(maximum), where=maximum>0)
            size_record = {'hotspot': info['hotspot'], 'contact_opaque_and_fixed': True,
                           'mean_luma_0_255': round(float(luminance.mean()*255), 2),
                           'mean_hsv_saturation': round(float(saturation.mean()), 4),
                           'native_partial_opacity_pixels': 0, 'frames': stats}
            gif_path = folder / 'native_transparent_previews' / f'{role}_{size}px.gif'
            with Image.open(gif_path) as gif:
                gif_delays, max_error = [], 0
                for step, frame in enumerate(ImageSequence.Iterator(gif)):
                    gif_delays.append(frame.info['duration'])
                    native = np.array(Image.open(frame_dir / f'{step:02}.png'))
                    preview = np.array(frame.convert('RGBA'))
                    assert np.array_equal(native[:, :, 3], preview[:, :, 3])
                    visible = native[:, :, 3] == 255
                    max_error = max(max_error, int(np.abs(native[:, :, :3][visible].astype(np.int16)-preview[:, :, :3][visible].astype(np.int16)).max()))
                assert len(gif_delays) == record['frames']
                assert abs(sum(gif_delays)-record['loop_ms']) < .1
                size_record['gif_frame_delays_ms'] = gif_delays
                size_record['gif_loop_ms'] = sum(gif_delays)
                size_record['gif_opacity_matches_native'] = True
                size_record['gif_max_rgb_quantization_error'] = max_error
            record['sizes'][str(size)] = size_record
        report['roles'][role] = record
    (target / 'display_checks.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({role: {key: value for key, value in data.items() if key != 'sizes'}
                      for role, data in report['roles'].items()}, indent=2))
    return report


def compare(after):
    previous = json.loads((BASELINE / 'native' / 'display_checks.json').read_text(encoding='utf-8'))
    result = {'scheme_unchanged': scheme_state() == json.loads((BASELINE / 'scheme_state.json').read_text()), 'roles': {}}
    assert result['scheme_unchanged'], 'Equipped cursor or mouse registry changed during work'
    for role in ROLES:
        record = {'timing_unchanged': after['roles'][role]['step_jiffies'] == previous['roles'][role]['step_jiffies'], 'sizes': {}}
        assert record['timing_unchanged']
        for size in (32, 48, 64):
            alpha_changes = 0
            for step in range(after['roles'][role]['frames']):
                old = np.array(Image.open(BASELINE / 'native' / f'{role}_native{size}' / f'{step:02}.png'))
                new = np.array(Image.open(EVIDENCE / 'after' / f'{role}_native{size}' / f'{step:02}.png'))
                alpha_changes += int(np.count_nonzero(old[:, :, 3] != new[:, :, 3]))
            assert alpha_changes == 0, (role, size, 'shape changed')
            before_stats, after_stats = previous['roles'][role]['sizes'][str(size)], after['roles'][role]['sizes'][str(size)]
            record['sizes'][str(size)] = {'alpha_pixel_changes': alpha_changes,
                'before_mean_luma': before_stats['mean_luma_0_255'], 'after_mean_luma': after_stats['mean_luma_0_255'],
                'before_saturation': before_stats['mean_hsv_saturation'], 'after_saturation': after_stats['mean_hsv_saturation']}
        result['roles'][role] = record
    # Actual native PNG pixels; nearest enlargement solely for inspection.
    sheet = Image.new('RGB', (760, 420), '#211b29')
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf', 16)
    for row, background in enumerate(('#ffffff', '#211b29')):
        draw.text((16, row*204+8), 'Native 64px color comparison', font=font, fill='#efc97d')
        for column, (title, folder) in enumerate((('Before', BASELINE / 'native'), ('Richer color', EVIDENCE / 'after'))):
            native = Image.open(folder / 'link_native64' / '00.png').convert('RGBA')
            composited = Image.new('RGBA', (64, 64), background)
            composited.alpha_composite(native)
            tile = composited.convert('RGB').resize((160, 160), Image.Resampling.NEAREST)
            x, y = 210+column*270, row*204+35
            sheet.paste(tile, (x, y))
            draw.text((x-110, y+64), title, font=font, fill='#f8ebd9')
    sheet.save(PACK / 'color_comparison.png')
    (PACK / 'color_display_diagnostics.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', action='store_true')
    args = parser.parse_args()
    if args.baseline:
        snapshot()
        inspect(BASELINE, BASELINE / 'native')
    else:
        compare(inspect(PACK, EVIDENCE / 'after'))
