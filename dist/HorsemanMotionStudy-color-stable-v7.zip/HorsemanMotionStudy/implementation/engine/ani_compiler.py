"""
ANI & CUR Binary Compiler
Pure Python encoder for Windows Static (.cur) and Animated (.ani) Cursor files.
No external third-party software required.
"""

import struct
import io
import ctypes
from typing import List, Tuple, Union
from PIL import Image


def scale_hotspot(hotspot_x: int, hotspot_y: int, source_width: int, source_height: int, size: int) -> tuple[int, int]:
    """Match Windows' positive half-up hotspot scaling, rather than banker's rounding."""
    sx = (2*hotspot_x*size+source_width)//(2*source_width)
    sy = (2*hotspot_y*size+source_height)//(2*source_height)
    return max(0, min(size-1, sx)), max(0, min(size-1, sy))


def _cur_image_payload(image: Image.Image, hotspot_x: int, hotspot_y: int, opaque: bool) -> tuple[bytes, bytes]:
    if image.mode != "RGBA":
        image = image.convert("RGBA")

    if not (1 <= image.width <= 256 and 1 <= image.height <= 256):
        raise ValueError("Cursor dimensions must be between 1 and 256 pixels.")
    if not (0 <= hotspot_x < image.width and 0 <= hotspot_y < image.height):
        raise ValueError("Hotspot must lie inside the cursor image.")
    pixels = image.load()
    color = bytearray()
    mask = bytearray()
    stride = ((image.width + 31) // 32) * 4
    for y in range(image.height - 1, -1, -1):
        row = bytearray(stride)
        for x in range(image.width):
            r, g, b, a = pixels[x, y]
            if opaque:
                if a not in (0, 255):
                    raise ValueError("Opaque encoding requires binary source alpha")
                color.extend((b, g, r) if a else (0, 0, 0))
            else:
                color.extend((b, g, r, a))
            if a == 0:
                row[x // 8] |= 0x80 >> (x % 8)
        if opaque:
            color.extend(bytes((-image.width * 3) % 4))
        mask.extend(row)
    dib = struct.pack(
        "<IiiHHIIiiII",
        40,
        image.width,
        image.height * 2,
        1,
        24 if opaque else 32,
        0,
        len(color) + len(mask),
        0,
        0,
        0,
        0,
    )
    payload = dib + bytes(color) + bytes(mask)
    entry = struct.pack(
        "<BBBBHHII",
        image.width if image.width < 256 else 0,
        image.height if image.height < 256 else 0,
        0,
        0,
        int(hotspot_x),
        int(hotspot_y),
        len(payload),
        0,
    )
    return entry, payload


def make_cur_binary(image: Image.Image, hotspot_x: int = 0, hotspot_y: int = 0, opaque: bool = False) -> bytes:
    """
    Creates a Windows .cur (Cursor) file binary from a PIL Image.
    A .cur file is an ICO format file with idType=2 and hotspot coordinates in place of plane counts.
    """
    entry, payload = _cur_image_payload(image, hotspot_x, hotspot_y, opaque)
    header = struct.pack("<HHH", 0, 2, 1)
    offset = 6 + 16
    entry = entry[:12] + struct.pack("<I", offset)
    return header + entry + payload


def make_multi_size_cur_binary(
    image: Image.Image,
    hotspot_x: int = 0,
    hotspot_y: int = 0,
    sizes: tuple[int, ...] = (64, 48, 32),
    opaque: bool = False,
) -> bytes:
    """Creates one .cur resource with 64/48/32 variants for Windows DPI picking."""
    if image.mode != "RGBA":
        image = image.convert("RGBA")
    if not (0 <= hotspot_x < image.width and 0 <= hotspot_y < image.height):
        raise ValueError("Hotspot must lie inside the source cursor image.")
    if not sizes or len(set(sizes)) != len(sizes):
        raise ValueError("Multi-size cursor resources need a non-empty unique size list.")
    if any(size < 1 or size > 256 for size in sizes):
        raise ValueError("Cursor resource sizes must be between 1 and 256 pixels.")
    entries = []
    payloads = []
    for size in sizes:
        resized = image if image.size == (size, size) else image.resize((size, size), Image.Resampling.LANCZOS)
        alpha = resized.getchannel("A").point(lambda a: 255 if a >= 128 else 0)
        resized = resized.convert("RGBA")
        resized.putalpha(alpha)
        sx, sy = scale_hotspot(hotspot_x, hotspot_y, image.width, image.height, size)
        entry, payload = _cur_image_payload(resized, sx, sy, opaque)
        entries.append(entry)
        payloads.append(payload)
    offset = 6 + 16 * len(entries)
    fixed_entries = []
    for entry, payload in zip(entries, payloads):
        fixed_entries.append(entry[:12] + struct.pack("<I", offset))
        offset += len(payload)
    return struct.pack("<HHH", 0, 2, len(entries)) + b"".join(fixed_entries) + b"".join(payloads)


def make_ani_binary(
    frames: List[Image.Image],
    hotspot_x: int = 0,
    hotspot_y: int = 0,
    jiffies: int = 6,
    rates: List[int] = None,
    opaque: bool = False,
    sizes: tuple[int, ...] | None = None,
) -> bytes:
    """
    Creates a Microsoft RIFF .ani (Animated Cursor) binary from a list of PIL Images.
    
    Structure:
    RIFF ('ACON')
      anih (ANIHEADER: cbSizeOf, cFrames, cSteps, cx, cy, cBitCount, cPlanes, jifRate, flags)
      rate (optional: per-frame jiffies)
      LIST ('fram')
        icon (frame 0 as CUR/ICO)
        icon (frame 1 as CUR/ICO)
        ...
    """
    if not frames:
        raise ValueError("At least one frame is required to create an animated cursor.")
    if jiffies < 1:
        raise ValueError("Frame duration must be at least one jiffy.")
    if any(im.size != frames[0].size for im in frames):
        raise ValueError("All animation frames must have the same dimensions.")
    if rates is not None and (len(rates) != len(frames) or any(r < 1 for r in rates)):
        raise ValueError("Rates must contain one positive duration per frame.")

    # Convert all frames to .cur binaries. Multi-size resources avoid Windows
    # shrinking a single 64px cursor into a dull 32px desktop cursor.
    if sizes:
        cur_binaries = [
            make_multi_size_cur_binary(im, hotspot_x, hotspot_y, sizes=sizes, opaque=opaque)
            for im in frames
        ]
    else:
        cur_binaries = [make_cur_binary(im, hotspot_x, hotspot_y, opaque=opaque) for im in frames]
    frame_count = len(cur_binaries)

    # 1. 'anih' chunk (36 bytes payload)
    # flags: 1 = AF_ICON
    flags = 1
    # 0x2 is AF_SEQUENCE, not a rate flag. Natural frame order needs no seq.

    anih_data = struct.pack(
        "<IIIIIIIII",
        36,           # cbSizeOf (size of ANIHEADER)
        frame_count,  # cFrames
        frame_count,  # cSteps
        frames[0].width if sizes else 0,
        frames[0].height if sizes else 0,
        24 if opaque else 32 if sizes else 0,
        1 if sizes else 0,
        jiffies,      # jifRate (default rate in 1/60th seconds, e.g. 6 = 100ms)
        flags,        # flags
    )
    anih_chunk = b"anih" + struct.pack("<I", len(anih_data)) + anih_data

    # 2. 'rate' chunk (optional)
    rate_chunk = b""
    if rates and len(rates) == frame_count:
        rate_data = struct.pack(f"<{frame_count}I", *rates)
        rate_chunk = b"rate" + struct.pack("<I", len(rate_data)) + rate_data

    # 3. 'LIST' chunk with type 'fram'
    fram_body = bytearray(b"fram")
    for cur_bytes in cur_binaries:
        # RIFF chunks inside LIST
        fram_body += b"icon" + struct.pack("<I", len(cur_bytes)) + cur_bytes
        # RIFF requires word-alignment (pad with 1 byte if odd size)
        if len(cur_bytes) % 2 == 1:
            fram_body += b"\x00"

    list_chunk = b"LIST" + struct.pack("<I", len(fram_body)) + bytes(fram_body)

    # Assemble complete RIFF container
    riff_body = b"ACON" + anih_chunk + rate_chunk + list_chunk
    riff_file = b"RIFF" + struct.pack("<I", len(riff_body)) + riff_body
    return riff_file


def save_cur(image: Image.Image, output_path: str, hotspot_x: int = 0, hotspot_y: int = 0) -> str:
    """Save an image as a Windows .cur file."""
    data = make_cur_binary(image, hotspot_x, hotspot_y)
    with open(output_path, "wb") as f:
        f.write(data)
    return output_path


def save_ani(
    frames: List[Image.Image],
    output_path: str,
    hotspot_x: int = 0,
    hotspot_y: int = 0,
    jiffies: int = 6,
    rates: List[int] = None,
    opaque: bool = False,
    sizes: tuple[int, ...] | None = None,
) -> str:
    """Save a list of frames as a Windows .ani file."""
    data = make_ani_binary(frames, hotspot_x, hotspot_y, jiffies, rates, opaque=opaque, sizes=sizes)
    with open(output_path, "wb") as f:
        f.write(data)
    return output_path


def verify_cursor_with_windows(file_path: str) -> Tuple[bool, str]:
    """
    Uses the Windows User32 API to test if the cursor file is valid and loadable by Windows.
    Returns (True, message) if valid, (False, error) otherwise.
    """
    try:
        user32 = ctypes.windll.user32
        user32.LoadCursorFromFileW.argtypes = [ctypes.c_wchar_p]
        user32.LoadCursorFromFileW.restype = ctypes.c_void_p
        user32.DestroyCursor.argtypes = [ctypes.c_void_p]
        user32.DestroyCursor.restype = ctypes.c_int
        h_cursor = user32.LoadCursorFromFileW(file_path)
        if h_cursor != 0:
            user32.DestroyCursor(h_cursor)
            return True, f"Successfully loaded by Windows User32 API (Handle: {h_cursor})"
        else:
            err = ctypes.GetLastError()
            return False, f"Failed to load cursor with Windows error code: {err}"
    except Exception as e:
        return False, f"Exception during verification: {e}"
