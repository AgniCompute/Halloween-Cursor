"""Shared, time-independent grading for the Horseman's painted source pieces."""
import numpy as np
from PIL import Image

HORSE_PARTS = frozenset(('body', 'cape', 'tail', 'front_upper', 'rear_upper', 'shin'))
COLOR_NOTE = (
    'Both Horseman roles use the same fixed saturation (1.25) and midtone depth '
    '(gamma 1.12), with a smooth shadow transition, applied to still source pieces '
    'before resizing and deformation. Alpha is unchanged; far limbs retain '
    'their intentional depth shading.'
)


def rich_materials(im):
    """Grade once before resampling, with a broad smooth shadow transition."""
    data = np.array(im.convert('RGBA'))
    rgb = data[:, :, :3].astype(np.float64) / 255
    lum = rgb @ np.array([.2126, .7152, .0722])
    richer = np.clip(lum[:, :, None] + 1.25 * (rgb - lum[:, :, None]), 0, 1) ** 1.12
    t = np.clip((rgb.max(axis=2) - .12) / .32, 0, 1)
    weight = (t * t * (3 - 2 * t))[:, :, None]
    data[:, :, :3] = np.round((rgb * (1 - weight) + richer * weight) * 255).astype(np.uint8)
    return Image.fromarray(data)
