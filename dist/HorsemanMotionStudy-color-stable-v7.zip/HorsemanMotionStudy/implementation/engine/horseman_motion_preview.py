"""Portable, actual-native preview for the three-role Horseman motion proof."""
import html
from pathlib import Path

from engine.ani_compiler import scale_hotspot


def write_preview(folder, roles, descriptions, native_hotspots=None):
    folder = Path(folder)
    native_hotspots = native_hotspots or {}
    cards = []
    choices = []
    for role, (frames, point, tick) in roles.items():
        title, description, _ = descriptions[role]
        points = native_hotspots.get(role, {})
        hx, hy = points.get('32', scale_hotspot(*point, 64, 64, 32))
        lx, ly = points.get('64', point)
        samples = []
        for size, scale, px, py, label in ((32, 1, hx, hy, '32px · native'),
                                         (64, 1, lx, ly, '64px · native'),
                                         (64, 2, lx, ly, '128px · 2× inspection')):
            display = size * scale
            samples.append(f'''<figure><div class="sprite" style="width:{display}px;height:{display}px">
<img src="native_transparent_previews/{role}_{size}px.gif" width="{display}" height="{display}" class="{'inspection' if scale > 1 else ''}" alt="{html.escape(title)} native {size}px animation{' enlarged two times' if scale > 1 else ''}">
<i style="left:{(px+.5)*scale}px;top:{(py+.5)*scale}px" aria-hidden="true"></i></div><figcaption>{label}</figcaption></figure>''')
        cards.append(f'''<article class="card" data-role="{role}"><div class="card-title"><span class="role">{html.escape(role)}</span><h2>{html.escape(title)}</h2></div>
<div class="stage">{''.join(samples)}</div><p>{html.escape(description)}</p><div class="card-foot"><span>{len(frames)*tick/60:.2f}s loop · {len(frames)} composites</span><button class="try" data-role="{role}" data-hx="{hx}" data-hy="{hy}">Try contact</button></div></article>''')
        choices.append(f'<button class="try role-choice" data-role="{role}" data-hx="{hx}" data-hy="{hy}" aria-pressed="{str(role == "pointer").lower()}">{html.escape(title)}</button>')
    pointer = native_hotspots.get('pointer', {}).get('32', scale_hotspot(*roles['pointer'][1], 64, 64, 32))
    sources = []
    for path in sorted((folder / 'source_art').rglob('*')):
        if path.is_file() and path.suffix.lower() in ('.png', '.jpg', '.jpeg', '.txt', '.md', '.json', '.py'):
            relative = path.relative_to(folder).as_posix()
            sources.append(f'<a href="{html.escape(relative, quote=True)}" target="_blank" rel="noopener">{html.escape(path.relative_to(folder / "source_art").as_posix())}</a>')
    document = '''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Horseman · Motion study</title><style>
:root{--bg:#17131c;--card:#211a28;--line:#3f304b;--text:#f8ebd9;--muted:#c0aecb;--gold:#ffc879;--stage:#211b29}*{box-sizing:border-box}body{margin:0;color:var(--text);background:radial-gradient(ellipse at 80% 0,#35213c 0,transparent 42%),var(--bg);font:15px/1.55 'Segoe UI',system-ui,sans-serif}main{max-width:1280px;margin:auto;padding:44px 28px 60px}.eyebrow{text-transform:uppercase;letter-spacing:.2em;font-size:11px;color:var(--gold);font-weight:650}header{max-width:780px;margin-bottom:28px}h1{font:52px/1.07 Georgia,serif;letter-spacing:-.045em;margin:12px 0 17px}header p{max-width:650px;color:var(--muted);margin:0}.toolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:15px 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line);margin-bottom:22px}.toolbar>span{font-size:12px;color:var(--muted);margin-right:5px}button{font:inherit;color:var(--text);background:#302438;border:1px solid #564060;border-radius:8px;padding:7px 12px;cursor:pointer}button:hover,button[aria-pressed=true]{color:var(--gold);border-color:var(--gold)}button:focus-visible{outline:2px solid #ffa94a;outline-offset:3px}.toggle{margin-left:auto}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}.card{background:var(--card);border:1px solid var(--line);border-radius:15px;overflow:hidden}.card-title{padding:17px 18px 15px}.role{font:10px/1.2 'Segoe UI',sans-serif;letter-spacing:.14em;text-transform:uppercase;color:var(--gold)}h2{font:23px/1.2 Georgia,serif;margin:5px 0 0}.stage{background:var(--stage);height:190px;display:flex;align-items:flex-end;justify-content:space-around;padding:16px 8px;color:#cfbdcf}.stage.light{color:#5a455f}figure{margin:0;text-align:center}.sprite{position:relative;line-height:0;margin:auto}.sprite img{display:block;max-width:none}.sprite .inspection{image-rendering:pixelated}.sprite i{display:none;position:absolute;width:5px;height:5px;background:#fff;border:1px solid #fa366e;border-radius:50%;transform:translate(-50%,-50%);pointer-events:none}.contacts .sprite i{display:block}figcaption{font-size:10px;line-height:1.3;margin-top:10px}.card>p{font-size:13px;color:var(--muted);margin:16px 18px;min-height:80px}.card-foot{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:0 18px 17px;font-size:11px;color:var(--muted)}.card-foot button{padding:5px 9px;font-size:11px}.practice{margin-top:28px;padding:23px;background:var(--card);border:1px solid var(--line);border-radius:15px}.practice h2,.source h2{font-size:27px;margin:0 0 9px}.practice p,.source p{color:var(--muted);font-size:13px;margin:0 0 15px}.choices{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}.choices button{font-size:12px}.target-pad{display:flex;align-items:center;justify-content:space-around;gap:12px;min-height:130px;padding:24px;background:#f3eee5;border-radius:11px;cursor:url('browser_cursors/pointer_32px.png') __HX__ __HY__,default}.target{width:18px;height:18px;padding:0;border:0;background:#744184;border-radius:50%;outline:3px solid #ccb491;outline-offset:5px;cursor:inherit}.target.hit{background:#ef9526}.result{margin-top:13px;color:var(--gold);font-size:12px;min-height:19px}.source{margin-top:26px}.source-links{display:flex;flex-wrap:wrap;gap:7px 17px;font-size:12px}a{color:var(--gold);text-decoration-color:#a27558;text-underline-offset:3px}.limits{margin-top:27px;padding-top:20px;border-top:1px solid var(--line);color:var(--muted);font-size:12px}.evidence{display:flex;gap:16px;flex-wrap:wrap;font-size:12px}@media(max-width:1050px){.grid{grid-template-columns:repeat(auto-fit,minmax(320px,1fr))}}@media(max-width:650px){main{padding:28px 16px 42px}h1{font-size:39px}.grid{grid-template-columns:1fr}.toggle{margin-left:0}.card>p{min-height:0}.stage{height:190px}.target-pad{padding:24px 13px}.practice{padding:19px}}
</style></head><body><main>
<header><div class="eyebrow">The Headless Horseman · Three-role motion study</div><h1>Little forms.<br>A lively dark fairytale.</h1><p>A stylized arrow to aim with, a pointing gauntlet for links, and an articulated Horseman for waiting. Clear shapes, warm embers, purple cloth, and motion that leaves the contact point steady.</p></header>
<div class="toolbar" aria-label="Animation background controls"><span>View on</span><button data-bg="dark" aria-pressed="true">Dark</button><button data-bg="white" aria-pressed="false">White</button><button data-bg="gray" aria-pressed="false">Gray</button><button data-bg="blue" aria-pressed="false">Blue</button><button data-bg="checker" aria-pressed="false">Checker</button><button id="contacts" class="toggle" aria-pressed="false">Show contacts</button></div>
<div class="grid">__CARDS__</div>
<section class="practice" id="practice"><h2>Try the contact</h2><p>Select a role and click the five small targets. The pad uses the actual Windows-rendered 32px still PNG as a browser cursor; the cards above show the animated frames.</p><div class="choices" aria-label="Contact-test cursor role">__CHOICES__</div><div class="target-pad" id="pad"><button class="target" aria-label="Contact target one"></button><button class="target" aria-label="Contact target two"></button><button class="target" aria-label="Contact target three"></button><button class="target" aria-label="Contact target four"></button><button class="target" aria-label="Contact target five"></button></div><div class="result" id="result" aria-live="polite">pointer · contact (__HX__, __HY__) · 0 of 5 targets hit</div></section>
<section class="source"><h2>From artwork to motion</h2><p>Generated source pieces are assembled and articulated with a code rig. The loop frames are composites, with procedural flame motion. They are not independently hand-drawn poses or physical flame simulation. Source files and exact provenance:</p><div class="source-links">__SOURCES__<a href="animation_manifest.json" target="_blank" rel="noopener">animation manifest</a></div></section>
<p class="limits">These GIFs come from delivered ANI files loaded by Windows and rendered one index at a time. Native 32px shows the actual disk-loader result; embedded resource selection is not assumed. GIF delays follow the ANI timing to centisecond precision; browser wall-clock timing remains unmeasured. Forced indices and successful loading do not verify automatic Windows playback or fluid character motion. This separate proof does not change the equipped scheme.</p>
<div class="evidence"><a href="review.gif" target="_blank" rel="noopener">Combined animated review</a><a href="windows_render_check_32px.png" target="_blank" rel="noopener">Native 32 contact sheet</a><a href="windows_render_check_64px.png" target="_blank" rel="noopener">Native 64 contact sheet</a><a href="source_contact.png" target="_blank" rel="noopener">Composite frames</a><a href="validation.json" target="_blank" rel="noopener">Frame validation</a><a href="muse_native_validation.json" target="_blank" rel="noopener">Native contacts</a><a href="build_identity.json" target="_blank" rel="noopener">Build identity</a></div>
</main><script>
const backgrounds={dark:'#211b29',white:'#fff',gray:'#f3f3f3',blue:'#0a64d8',checker:'repeating-conic-gradient(#eee 0% 25%,#777 0% 50%) 0/16px 16px'};
document.querySelectorAll('[data-bg]').forEach(button=>button.addEventListener('click',()=>{document.querySelectorAll('[data-bg]').forEach(other=>other.setAttribute('aria-pressed',String(other===button)));document.querySelectorAll('.stage').forEach(stage=>{stage.style.background=backgrounds[button.dataset.bg];stage.classList.toggle('light',['white','gray','checker'].includes(button.dataset.bg))})}));
document.getElementById('contacts').addEventListener('click',event=>{const enabled=document.body.classList.toggle('contacts');event.currentTarget.setAttribute('aria-pressed',String(enabled))});
let currentRole='pointer',contactX=__HX__,contactY=__HY__,hits=0;
const result=document.getElementById('result'),pad=document.getElementById('pad');
const update=()=>result.textContent=`${currentRole} · contact (${contactX}, ${contactY}) · ${hits} of 5 targets hit`;
document.querySelectorAll('.try').forEach(button=>button.addEventListener('click',()=>{currentRole=button.dataset.role;contactX=Number(button.dataset.hx);contactY=Number(button.dataset.hy);hits=0;document.querySelectorAll('.target').forEach(target=>target.classList.remove('hit'));document.querySelectorAll('.role-choice').forEach(choice=>choice.setAttribute('aria-pressed',String(choice.dataset.role===currentRole)));pad.style.cursor=`url('browser_cursors/${currentRole}_32px.png') ${contactX} ${contactY},crosshair`;update();if(!button.classList.contains('role-choice'))document.getElementById('practice').scrollIntoView({behavior:'smooth',block:'center'})}));
document.querySelectorAll('.target').forEach(target=>target.addEventListener('click',()=>{if(!target.classList.contains('hit')){target.classList.add('hit');hits++}update()}));
</script></body></html>'''
    for token, replacement in {'__CARDS__': '\n'.join(cards), '__CHOICES__': ''.join(choices),
                               '__SOURCES__': ''.join(sources), '__HX__': str(pointer[0]),
                               '__HY__': str(pointer[1])}.items():
        document = document.replace(token, replacement)
    (folder / 'preview.html').write_text(document, encoding='utf-8')
