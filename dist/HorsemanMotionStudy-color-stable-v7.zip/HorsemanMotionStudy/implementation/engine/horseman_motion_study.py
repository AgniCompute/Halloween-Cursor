"""Smooth illustrated role shapes and keyed 2D motion, using generated parts.

The source images are still illustrations. Leg poses below are composites made
with a two-link rig; flames/ribbons use authored periodic image deformations.
Neither technique is independently drawn animation or physical simulation.
"""
import math
from functools import lru_cache
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
from engine.ani_compiler import scale_hotspot
from engine.horseman_color import HORSE_PARTS, COLOR_NOTE, rich_materials

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT/'assets'/'horseman_motion_study'
SCALE = 4
SIDE = 64*SCALE

def binary(im):
    im = im.convert('RGBA')
    im.putalpha(im.getchannel('A').point(lambda a: 255 if a >= 128 else 0))
    return im

@lru_cache(maxsize=16)
def load(name):
    im = Image.open(ASSETS/f'{name}.png').convert('RGBA')
    # Connected-source extraction excludes the atlas' faint background haze.
    im.putalpha(im.getchannel('A').point(lambda a: a if a >= 128 else 0))
    return rich_materials(im) if name in HORSE_PARTS else im

def canvas():
    return Image.new('RGBA',(SIDE,SIDE))

def resize_on_canvas(im, box):
    x,y,w,h = box
    out = canvas()
    out.alpha_composite(im.resize((round(w*SCALE),round(h*SCALE)),Image.Resampling.LANCZOS),(round(x*SCALE),round(y*SCALE)))
    return out

def polygon_layer(im, points):
    mask = Image.new('L',im.size)
    ImageDraw.Draw(mask).polygon(points, fill=255)
    layer = im.copy()
    layer.putalpha(Image.fromarray((np.array(im.getchannel('A'),dtype=np.uint16)*np.array(mask,dtype=np.uint16)//255).astype(np.uint8)))
    back = im.copy()
    back.putalpha(Image.fromarray((np.array(im.getchannel('A'),dtype=np.uint16)*(255-np.array(mask,dtype=np.uint16))//255).astype(np.uint8)))
    return back,layer

def remap(layer, x, y):
    """Bilinear RGBA resampling in premultiplied color to avoid dark fringes."""
    a = np.array(layer,dtype=np.float32)/255
    a[:,:,:3] *= a[:,:,3:4]
    x0,y0 = np.floor(x).astype(int),np.floor(y).astype(int)
    tx,ty = (x-x0)[...,None],(y-y0)[...,None]
    result = np.zeros_like(a)
    for ox,oy,weight in ((0,0,(1-tx)*(1-ty)),(1,0,tx*(1-ty)),(0,1,(1-tx)*ty),(1,1,tx*ty)):
        xx,yy = x0+ox,y0+oy
        valid = (xx>=0)&(xx<SIDE)&(yy>=0)&(yy<SIDE)
        result[valid] += a[yy[valid],xx[valid]]*weight[valid]
    result[:,:,:3] = np.divide(result[:,:,:3],result[:,:,3:4],out=np.zeros_like(result[:,:,:3]),where=result[:,:,3:4]>0)
    return Image.fromarray(np.clip(result*255,0,255).astype(np.uint8))

def flow(layer, anchor, phase, mode, amplitude=2.7):
    """Rooted, asymmetric shape changes with delayed secondary motion."""
    yy,xx = np.mgrid[:SIDE,:SIDE].astype(float)
    ax,ay = np.array(anchor)*SCALE
    t = phase*math.tau
    if mode == 'flame':
        free = np.clip((ay-yy)/(18*SCALE),0,1)
        dx = amplitude*SCALE*free*(math.sin(t)+.34*np.sin(2*t+free*2.1))
        length = 1+.11*math.sin(t-.6)
        sy = ay+(yy-ay)/(1+(length-1)*free)
        return remap(layer,xx-dx,sy)
    free = np.clip((xx-ax)/(17*SCALE),0,1)
    dy = amplitude*SCALE*free*(np.sin(t-free*1.7)+.22*np.sin(2*t-free*3))
    stretch = 1+.03*math.sin(t+.8)
    sx = ax+(xx-ax)/(1+(stretch-1)*free)
    return remap(layer,sx,yy-dy)

def finish(im):
    return binary(im.resize((64,64),Image.Resampling.LANCZOS))

def find_contact(im, target):
    pixels=np.array(im.getchannel('A'))
    small={size:np.array(binary(im.resize((size,size),Image.Resampling.LANCZOS)).getchannel('A')) for size in (32,48)}
    native32=np.array(im.resize((32,32),Image.Resampling.NEAREST).getchannel('A'))
    candidates=[]
    for y,x in zip(*np.where(pixels==255)):
        if any(a[scale_hotspot(x,y,64,64,size)[1],scale_hotspot(x,y,64,64,size)[0]]!=255 for size,a in small.items()):
            continue
        sx,sy=scale_hotspot(x,y,64,64,32)
        if native32[sy,sx]!=255:
            continue
        candidates.append(((x-target[0])**2+(y-target[1])**2,int(x),int(y)))
    assert candidates
    _,x,y=min(candidates)
    return x,y

def still_contact(frame, first, hotspot, radius=2):
    x,y=hotspot
    box=(x-radius,y-radius,x+radius+1,y+radius+1)
    frame.paste(first.crop(box),box[:2])
    return frame

def quiet_cursor(role):
    source=load(f'{role}-source')
    bounds=source.getchannel('A').getbbox()
    x0,y0,x1,y1=bounds
    if role=='pointer':
        w,h=54,54*(y1-y0)/(x1-x0)
        position=(4,4,w,h)
        fire=[(769,751),(776,702),(818,644),(864,636),(910,605),(910,563),(953,534),(1000,506),(1012,460),(985,395),(1059,395),(1109,460),(1110,642),(1047,728),(920,779),(810,780)]
        ribbon=[(871,786),(1010,778),(1130,776),(1212,808),(1212,1035),(1090,1035),(990,980),(920,975),(869,924)]
        fire_root=(791,748)
        ribbon_root=(879,838)
        target=(4,4)
    else:
        h=55
        w=h*(x1-x0)/(y1-y0)
        position=(6,4,w,h)
        fire=[(844,1020),(846,970),(877,921),(917,881),(953,837),(1007,815),(1024,779),(1009,730),(1056,727),(1095,779),(1098,910),(1078,970),(993,1038),(900,1044)]
        ribbon=[(950,1022),(1056,1004),(1150,1015),(1210,1049),(1210,1200),(1150,1200),(1078,1161),(979,1146),(947,1123)]
        fire_root=(873,1020)
        ribbon_root=(952,1060)
        target=(20,4)
    base, flame=polygon_layer(source,fire)
    base,ribbon_art=polygon_layer(base,ribbon)
    def prepare(part):
        return resize_on_canvas(part.crop(bounds),position)
    base,flame,ribbon_art=map(prepare,(base,flame,ribbon_art))
    def transformed_point(point):
        return (position[0]+(point[0]-x0)*w/(x1-x0),position[1]+(point[1]-y0)*h/(y1-y0))
    fire_root,ribbon_root=map(transformed_point,(fire_root,ribbon_root))
    frames=[]
    for index in range(48):
        phase=index/48
        im=base.copy()
        im.alpha_composite(flow(ribbon_art,ribbon_root,phase-.14,'ribbon',3))
        im.alpha_composite(flow(flame,fire_root,phase,'flame',2.7))
        frames.append(finish(im))
    hotspot=find_contact(frames[0],target)
    frames=[still_contact(frame,frames[0],hotspot) for frame in frames]
    return frames,hotspot,2

def pointer_cursor():
    """A rigid 45-degree role silhouette with generated paint and ornaments."""
    source=load('pointer-source-straight-v3')
    base=canvas()
    draw=ImageDraw.Draw(base)
    def points(values):
        return [(x*SCALE,y*SCALE) for x,y in values]
    outer=[(4,4),(42,17),(30,23),(46,39),(39,46),(23,30),(17,42)]
    gold=[(6,6),(39,17),(28,22),(44,39),(39,44),(22,28),(17,39)]
    inner=[(9,9),(35,17),(25,21),(41,39),(39,41),(21,25),(17,35)]
    draw.polygon(points(outer),fill=(28,10,34,255))
    draw.polygon(points(gold),fill=(247,202,107,255))
    draw.polygon(points(inner),fill=(83,28,91,255))
    mask=Image.new('L',base.size)
    ImageDraw.Draw(mask).polygon(points(inner),fill=255)
    paint=source.crop((250,350,450,550)).resize((38*SCALE,38*SCALE),Image.Resampling.LANCZOS)
    texture=canvas();texture.alpha_composite(paint,(4*SCALE,4*SCALE))
    texture.putalpha(Image.fromarray((np.array(texture.getchannel('A'),dtype=np.uint16)*np.array(mask,dtype=np.uint16)//255).astype(np.uint8)))
    base.alpha_composite(texture)
    draw=ImageDraw.Draw(base)
    draw.line(points([(6,6),(39,17)]),fill=(255,238,193,255),width=3)
    draw.line(points([(6,6),(17,39)]),fill=(255,221,145,255),width=3)
    fire_poly=[(769,797),(772,712),(845,651),(922,618),(923,576),(968,539),(1013,511),(1016,460),(987,411),(1058,406),(1092,464),(1096,644),(1050,720),(973,785),(835,814)]
    ribbon_poly=[(862,831),(953,817),(1090,809),(1229,839),(1229,1095),(1130,1095),(1070,1031),(986,1002),(857,945)]
    _,flame=polygon_layer(source,fire_poly)
    _,ribbon=polygon_layer(source,ribbon_poly)
    bounds=source.getchannel('A').getbbox()
    x0,y0,x1,y1=bounds
    scale=50/(x1-x0)
    h=(y1-y0)*scale
    def place(part,source_root,target):
        px,py=4+(source_root[0]-x0)*scale,4+(source_root[1]-y0)*scale
        return resize_on_canvas(part.crop(bounds),(4+target[0]-px,4+target[1]-py,50,h))
    flame=place(flame,(791,787),(37,34))
    ribbon=place(ribbon,(879,873),(37,37))
    jewel=source.crop((582,686,722,826))
    circle=Image.new('L',jewel.size)
    ImageDraw.Draw(circle).ellipse((0,0,jewel.width-1,jewel.height-1),fill=255)
    jewel.putalpha(Image.fromarray((np.array(jewel.getchannel('A'),dtype=np.uint16)*np.array(circle,dtype=np.uint16)//255).astype(np.uint8)))
    gem=resize_on_canvas(jewel,(30,30,8,8))
    frames=[]
    for index in range(48):
        im=base.copy()
        im.alpha_composite(flow(ribbon,(37,37),index/48-.14,'ribbon',2.5))
        im.alpha_composite(flow(flame,(37,34),index/48,'flame',2.1))
        im.alpha_composite(gem)
        frames.append(finish(im))
    hotspot=find_contact(frames[0],(6,6))
    frames=[still_contact(frame,frames[0],hotspot) for frame in frames]
    return frames,hotspot,2

def keyed(values,phase):
    """Periodic Catmull-Rom interpolation through authored gait angles."""
    position=(phase%1)*len(values)
    i=int(position)
    t=position-i
    p0,p1,p2,p3=(values[(i+offset)%len(values)] for offset in (-1,0,1,2))
    return .5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t)

def segment(im,part,source_root,source_end,root,end,shade=1,transverse_length=None):
    sx,sy=np.array(source_end)-source_root
    dx,dy=(np.array(end)-root)*SCALE
    den=sx*sx+sy*sy
    a,b=(dx*sx+dy*sy)/den,(dy*sx-dx*sy)/den
    invden=a*a+b*b
    ia,ib=a/invden,b/invden
    rx,ry=np.array(root)*SCALE
    transform=(ia,ib,source_root[0]-ia*rx-ib*ry,-ib,ia,source_root[1]+ib*rx-ia*ry)
    if transverse_length is not None:
        # Stretch along the bone only; keep painted thickness independent
        # of reach so the shoulder does not inflate during extension.
        source_length=math.sqrt(den)
        target_length=math.hypot(dx,dy)
        su,sv=sx/source_length,sy/source_length
        tu,tv=dx/target_length,dy/target_length
        longitudinal=source_length/target_length
        transverse=source_length/(transverse_length*SCALE)
        m00=longitudinal*su*tu+transverse*sv*tv
        m01=longitudinal*su*tv-transverse*sv*tu
        m10=longitudinal*sv*tu-transverse*su*tv
        m11=longitudinal*sv*tv+transverse*su*tu
        transform=(m00,m01,source_root[0]-m00*rx-m01*ry,
                   m10,m11,source_root[1]-m10*rx-m11*ry)
    if shade!=1:
        array=np.array(part)
        array[:,:,:3]=(array[:,:,:3].astype(float)*shade).astype(np.uint8)
        part=Image.fromarray(array)
    layer=part.transform((SIDE,SIDE),Image.Transform.AFFINE,transform,Image.Resampling.BICUBIC)
    im.alpha_composite(layer)

BOB=(-1.3,0,.7,1.3,.8,-.3,-1.5,-2.2)
STANCE=.24
# Transverse four-beat order: trailing hind, leading hind, trailing fore,
# leading fore, then suspension. A stylized kinematic cycle, not a simulation.
CONTACTS={'rear_far':.04,'rear_near':.14,'front_far':.36,'front_near':.47}

def hoof_path(kind,base_x,phase):
    """Grounded sweep followed by a lifted recovery, with matching x velocity."""
    front=kind=='front'
    start,end=(-7,7) if front else (-6,8)
    ground=54 if front else 53.5
    if phase<STANCE:
        return base_x+start+(end-start)*phase/STANCE,ground,True
    u=(phase-STANCE)/(1-STANCE)
    tangent=(end-start)*(1-STANCE)/STANCE
    h00,h10,h01,h11=2*u**3-3*u**2+1,u**3-2*u**2+u,-2*u**3+3*u**2,u**3-u**2
    x=h00*end+h10*tangent+h01*start+h11*tangent
    y=ground-(9 if front else 10)*math.sin(math.pi*u)**1.5
    return base_x+x,y,False

def leg_joints(kind,root,phase):
    fx,fy,planted=hoof_path(kind,root[0],phase)
    dx,dy=fx-root[0],fy-2.7-root[1]
    distance=math.hypot(dx,dy)
    length=9.5
    # Equal-length two-link IK; the fore knee folds forward, the hind hock
    # backward. The hoof is driven by one path rather than a second angle loop.
    distance=min(2*length-.02,max(.1,distance))
    ux,uy=dx/math.hypot(dx,dy),dy/math.hypot(dx,dy)
    reach=distance/2
    bend=math.sqrt(max(0,length*length-reach*reach))
    if kind=='front':
        # A supporting foreleg reads with natural equine forward carpus angle and
        # folds cleanly into recovery so the shoulder stays attached.
        distance=math.hypot(dx,dy)
        reach=distance*.44
        recovery=(phase-STANCE)/(1-STANCE)
        fold=0.0
        if not planted:
            ramp=min(1.0,max(0.0,min(recovery,1-recovery)/.16))
            fold=ramp*ramp*(3-2*ramp)
        bend=2.6+(bend-2.6)*fold
    sign=-1 if kind=='front' else 1
    knee=(root[0]+ux*reach+sign*uy*bend,root[1]+uy*reach-sign*ux*bend)
    ankle=(root[0]+ux*distance,root[1]+uy*distance)
    return knee,ankle,planted

def leg(im,kind,root,phase,shade):
    is_front=kind=='front'
    upper=load('front_upper' if is_front else 'rear_upper').crop((0,0,304 if is_front else 353,250))
    knee,ankle,planted=leg_joints(kind,root,phase)
    draw=ImageDraw.Draw(im)
    ink=tuple(round(v*shade) for v in (43,14,44))+(255,)
    if is_front:
        # Anatomical foreleg contour: substantial shoulder/forearm tapering
        # to a distinct carpal knee joint and sturdy fetlock above the hoof.
        def limb_quad(start,end,r0,r1):
            ldx,ldy=end[0]-start[0],end[1]-start[1]
            l=math.hypot(ldx,ldy)
            nx,ny=-ldy/l,ldx/l
            return [(start[0]+nx*r0,start[1]+ny*r0),
                    (end[0]+nx*r1,end[1]+ny*r1),
                    (end[0]-nx*r1,end[1]-ny*r1),
                    (start[0]-nx*r0,start[1]-ny*r0)]
        upper_quad=limb_quad(root,knee,3.0,2.3)
        lower_quad=limb_quad(knee,ankle,2.3,2.2)
        for quad in (upper_quad,lower_quad):
            draw.polygon([(round(x*SCALE),round(y*SCALE)) for x,y in quad],fill=ink)
        for pt,r in ((root,3.0),(knee,2.4),(ankle,2.2)):
            x,y=round(pt[0]*SCALE),round(pt[1]*SCALE)
            rad=round(r*SCALE)
            draw.ellipse((x-rad,y-rad,x+rad,y+rad),fill=ink)
    else:
        joints=[tuple(round(v*SCALE) for v in point) for point in (root,knee,ankle)]
        width=round(3.5*SCALE)
        draw.line(joints,fill=ink,width=width,joint='curve')
        radius=width/2
        for x,y in joints:
            draw.ellipse((x-radius,y-radius,x+radius,y+radius),fill=ink)
    segment(im,upper,(233,50) if is_front else (92,64),(95,213) if is_front else (247,221),root,knee,shade)
    # The hoof is a separate rigid shoe. It stays level during support rather
    # than rotating with the shin and appearing to paddle through the floor.
    shin=load('shin')
    segment(im,shin.crop((0,0,shin.width,285)),(89,20),(94,273),knee,ankle,shade)
    u=(phase-STANCE)/(1-STANCE)
    angle=0 if planted else math.radians(12)*math.sin(math.tau*u)
    toe=(ankle[0]+2.7*math.sin(angle),ankle[1]+2.7*math.cos(angle))
    segment(im,shin.crop((0,270,shin.width,shin.height)),(94,20),(94,111),ankle,toe,shade)

def busy():
    frames=[]
    for index in range(24):
        phase=index/24
        bob=keyed(BOB,phase)
        im=canvas()
        tail=resize_on_canvas(load('tail'),(43,21+bob,16,16))
        im.alpha_composite(flow(tail,(44,35+bob),phase-.2,'flame',2.2))
        leg(im,'front',(24,37+bob),(phase-CONTACTS['front_far'])%1,.64)
        leg(im,'rear',(39,37+bob),(phase-CONTACTS['rear_far'])%1,.64)
        cape=resize_on_canvas(load('cape'),(30,15+bob,24,12.4))
        im.alpha_composite(flow(cape,(31,19+bob),phase-.22,'ribbon',1.7))
        im.alpha_composite(resize_on_canvas(load('body'),(7,7+bob,39,34)))
        # Near shoulder/haunch caps overlap the torso visibly; only the far
        # legs are occluded by it. Roots travel with the same body offset.
        leg(im,'front',(22,35+bob),(phase-CONTACTS['front_near'])%1,1)
        leg(im,'rear',(41,35+bob),(phase-CONTACTS['rear_near'])%1,1)
        frames.append(finish(im))
    hotspot=find_contact(frames[0],(36,36))
    # A tiny saddle contact stays still while the outer body rises/falls. It is
    # part of the rig's fixed contact, not a source-pose continuity claim.
    frames=[still_contact(frame,frames[0],hotspot,2) for frame in frames]
    return frames,hotspot,2

DESCRIPTIONS={
    'pointer':('Ember arrow','A straight rigid arrow with aligned head and shaft; a rooted flame and ribbon move at the heel.',['pointer-source-straight-v3.png']),
    'link':('Pointing gauntlet','A readable pointing hand; its fingertip stays still while the cuff flame and ribbon flow.',['link-source.png']),
    'busy':('Horseman gallop','A Horseman in deep violet and ember gold gallops with four timed footfalls, folded recovery and a suspension phase; cape and flame tail follow the body.',['busy-rig-source.png']),
}
PROVENANCE={
    'pointer':dict(source_assets=['pointer-source-straight-v3.png'],generated_source_poses={'pointer':1},source_pose_count=1,motion_method='code-defined symmetric45-degree rigid outline with parallel shaft sides, generated interior paint and isolated jewel/flame/ribbon from one still illustration; only flame/ribbon deform;48 composites at30fps'),
    'link':dict(source_assets=['link-source.png'],generated_source_poses={'hand':1},source_pose_count=1,motion_method='single still illustration split into fixed hand, flame and ribbon; root-weighted periodic image deformations;48 composites at30fps'),
    'busy':dict(source_assets=['busy-rig-source.png','body.png','cape.png','tail.png','front_upper.png','rear_upper.png','shin.png'],generated_source_poses={'body':1,'cape':1,'tail':1,'front_upper':1,'rear_upper':1,'shin':1},source_pose_count=1,source_piece_count=6,motion_method='six generated still pieces; four two-link IK legs follow ground sweeps and lifted Hermite recovery paths with coordinated hind-hind-fore-fore contacts and suspension; tapered 6.0-to-4.4px foreleg anatomical contour with 2.6px forward knee bend in stance, and rounded 3.5px hind contour; fore knee at 44% reach with natural artwork aspect ratios; body rise/fall and cape/tail deformation; 24 composites at 30fps',fixed_contact_note='5x5 saddle patch copied from first composite; click point never moves'),
}

PROVENANCE['busy']['color_effect_note'] = COLOR_NOTE

def build_roles():
    roles={'pointer':pointer_cursor(),'link':quiet_cursor('link'),'busy':busy()}
    for role,(frames,hotspot,tick) in roles.items():
        assert len({frame.tobytes() for frame in frames})>2,role
        for frame in frames:
            alpha=np.array(frame.getchannel('A'))
            assert not any((alpha[0].any(),alpha[-1].any(),alpha[:,0].any(),alpha[:,-1].any())),(role,'clipped')
            assert frame.getpixel(hotspot)[3]==255,(role,'contact')
    return roles
