"""
Preview Generator
Generates animated preview GIFs for each cursor role, a combined animated banner showcase,
and an interactive HTML testbed where users can hover and test every cursor directly in browser.
"""

import os
import base64
from typing import Dict, List, Tuple
import numpy as np
from PIL import Image


def gif_palette_frames(frames):
    """Use one opaque-color palette for the loop; reserve zero for transparency.

    A fixed RGB color maps to the same index in every frame. Hidden pixels do
    not consume palette entries, and dithering cannot vary a still patch as
    neighbouring effects move. Bound the quantizer sample for large previews.
    """
    frames = [frame.convert('RGBA') for frame in frames]
    if not frames:
        raise ValueError('An animated GIF requires at least one frame')
    budget = 1_048_576
    stride = max(1, (sum(frame.width * frame.height for frame in frames) + budget - 1) // budget)
    samples = []
    for frame in frames:
        data = np.asarray(frame)
        opaque = data[:, :, :3][data[:, :, 3] >= 128]
        samples.append(opaque[::stride])
    colors = np.concatenate(samples)
    if not len(colors):
        colors = np.zeros((1, 3), dtype=np.uint8)
    master = Image.fromarray(colors.reshape(1, -1, 3)).quantize(
        colors=255, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    palette = master.getpalette()[:765]
    palette += palette[:3] * ((765 - len(palette)) // 3)
    # Pillow's fixed-palette mapper considers all 256 entries. Make the unused
    # last entry a duplicate and fold it back before reserving index zero.
    master.putpalette(palette + palette[:3])
    converted = []
    for frame in frames:
        pal = frame.convert('RGB').quantize(palette=master, dither=Image.Dither.NONE)
        indices = np.asarray(pal).astype(np.uint16)
        indices[indices == 255] = 0
        pixels = np.where(np.asarray(frame.getchannel('A')) >= 128, indices + 1, 0).astype(np.uint8)
        out = Image.fromarray(pixels)
        out.putpalette([0, 0, 0] + palette)
        out.info["transparency"] = 0
        converted.append(out)
    return converted


def gif_timing(frame_count, jiffies):
    """GIF stores centiseconds: distribute rounding to preserve ANI loop length."""
    return [(round((i+1)*jiffies*100/60)-round(i*jiffies*100/60))*10
            for i in range(frame_count)]


def generate_animated_gif(
    frames: List[Image.Image],
    output_path: str,
    duration_ms: int = 100,
    scale_factor: int = 4,
    jiffies: int = None,
) -> str:
    """
    Saves a sequence of frames as an animated GIF scaled up for crisp pixel art preview.
    """
    scaled_frames = [
        im.resize((im.width * scale_factor, im.height * scale_factor), resample=Image.Resampling.NEAREST)
        for im in gif_palette_frames(frames)
    ]
    scaled_frames[0].save(
        output_path,
        save_all=True,
        append_images=scaled_frames[1:],
        duration=gif_timing(len(frames), jiffies) if jiffies is not None else duration_ms,
        loop=0,
        disposal=2,
        transparency=0,
        background=0,
        optimize=False,
    )
    return output_path


def generate_html_preview(
    output_path: str,
    scheme_name: str,
    cursor_data: Dict[str, Tuple[List[Image.Image], Tuple[int, int], int, str]],
) -> str:
    """
    Generates a rich, interactive HTML preview testbed.
    Each card allows the user to hover and preview the cursor in action.
    """
    cards_html = []

    for role, (frames, (hx, hy), jiffies, cur_filename) in cursor_data.items():
        # Generate base64 animated gif for embedding
        gif_frames = [
            im.resize((im.width * 3, im.height * 3), resample=Image.Resampling.NEAREST)
            for im in gif_palette_frames(frames)
        ]
        import io
        buf = io.BytesIO()
        gif_frames[0].save(
            buf,
            format="GIF",
            save_all=True,
            append_images=gif_frames[1:],
            duration=gif_timing(len(frames), jiffies),
            loop=0,
            disposal=2,
            transparency=0,
            background=0,
            optimize=False,
        )
        b64_gif = base64.b64encode(buf.getvalue()).decode("utf-8")

        card = f"""
        <div class="cursor-card" style="cursor: url('{cur_filename}'), auto;">
            <div class="cursor-preview">
                <img src="data:image/gif;base64,{b64_gif}" alt="{role}" />
            </div>
            <div class="cursor-info">
                <div class="cursor-title">{role.upper()}</div>
                <div class="cursor-meta">Hotspot: ({hx}, {hy}) | {len(frames)} frames</div>
                <div class="hover-hint">Hover here to test cursor</div>
            </div>
        </div>
        """
        cards_html.append(card)

    cards_joined = "\n".join(cards_html)

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{scheme_name} - Cursor Preview</title>
    <style>
        :root {{
            --bg-color: #12101a;
            --card-bg: #1e1b2e;
            --card-hover: #2a2542;
            --accent: #d2a8ff;
            --text-main: #f0eafc;
            --text-sub: #a39bc0;
            --border: #383259;
        }}
        * {{
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }}
        body {{
            background-color: var(--bg-color);
            color: var(--text-main);
            padding: 40px 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }}
        header {{
            text-align: center;
            margin-bottom: 40px;
        }}
        h1 {{
            font-size: 2.2rem;
            color: var(--accent);
            margin-bottom: 8px;
            letter-spacing: -0.5px;
        }}
        p.subtitle {{
            color: var(--text-sub);
            font-size: 1rem;
        }}
        .grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 20px;
            width: 100%;
            max-width: 1100px;
        }}
        .cursor-card {{
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            transition: transform 0.15s ease, border-color 0.15s ease;
        }}
        .cursor-card:hover {{
            transform: translateY(-4px);
            border-color: var(--accent);
            background: var(--card-hover);
        }}
        .cursor-preview {{
            width: 96px;
            height: 96px;
            background: repeating-conic-gradient(#171424 0% 25%, #221d36 0% 50%) 50% / 16px 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 16px;
            border: 1px solid var(--border);
        }}
        .cursor-preview img {{
            image-rendering: pixelated;
        }}
        .cursor-title {{
            font-weight: 700;
            font-size: 1.05rem;
            color: var(--text-main);
            margin-bottom: 4px;
        }}
        .cursor-meta {{
            font-size: 0.8rem;
            color: var(--text-sub);
            margin-bottom: 8px;
        }}
        .hover-hint {{
            font-size: 0.75rem;
            color: var(--accent);
            opacity: 0.85;
            padding: 4px 8px;
            background: rgba(210, 168, 255, 0.1);
            border-radius: 4px;
        }}
        footer {{
            margin-top: 50px;
            color: var(--text-sub);
            font-size: 0.85rem;
            text-align: center;
        }}
    </style>
</head>
<body>
    <header>
        <h1>✨ {scheme_name} ✨</h1>
        <p class="subtitle">Complete 17-Role Windows Animated Cursor Set (Hover any card to test the cursor live!)</p>
    </header>
    
    <div class="grid">
        {cards_joined}
    </div>

    <footer>
        <p>Built with Pure Python & AI Autonomous Cursor Engine. Ready to install via <code>install.inf</code>.</p>
    </footer>
</body>
</html>
"""
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    return output_path
