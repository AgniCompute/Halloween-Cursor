import ctypes
import json
import struct
import sys
from pathlib import Path
import numpy as np

from PIL import Image, ImageDraw

from engine.preview_gen import gif_timing, generate_animated_gif


class ICONINFO(ctypes.Structure):
    _fields_ = [
        ("fIcon", ctypes.c_bool),
        ("xHotspot", ctypes.c_uint32),
        ("yHotspot", ctypes.c_uint32),
        ("hbmMask", ctypes.c_void_p),
        ("hbmColor", ctypes.c_void_p),
    ]


class BITMAP(ctypes.Structure):
    _fields_ = [
        ("bmType", ctypes.c_long),
        ("bmWidth", ctypes.c_long),
        ("bmHeight", ctypes.c_long),
        ("bmWidthBytes", ctypes.c_long),
        ("bmPlanes", ctypes.c_ushort),
        ("bmBitsPixel", ctypes.c_ushort),
        ("bmBits", ctypes.c_void_p),
    ]


def fail(message):
    raise RuntimeError(message)


def ani_frame_info(path):
    data = Path(path).read_bytes()
    if data[:4] != b"RIFF" or data[8:12] != b"ACON":
        fail(f"{Path(path).name} is not a RIFF ACON file")
    off = 12
    while off + 8 <= len(data):
        tag = data[off : off + 4]
        size = struct.unpack_from("<I", data, off + 4)[0]
        body = off + 8
        if tag == b"anih":
            fields = struct.unpack("<9I", data[body : body + size])
            return fields[1], fields[7]
        off = body + size + (size & 1)
    fail(f"{Path(path).name} has no anih chunk")


def riff_chunks(data, start, end):
    while start + 8 <= end:
        tag = data[start : start + 4]
        size = struct.unpack_from("<I", data, start + 4)[0]
        body = start + 8
        yield tag, body, size
        start = body + size + (size & 1)


def embedded_alpha_checks(path):
    data = Path(path).read_bytes()
    corner_violations = []
    edge_violations = []
    transparent_hotspots = []
    for tag, body, size in riff_chunks(data, 12, len(data)):
        if tag != b"LIST" or data[body : body + 4] != b"fram":
            continue
        for frame_index, (subtag, subbody, subsize) in enumerate(riff_chunks(data, body + 4, body + size)):
            if subtag != b"icon":
                continue
            icon = data[subbody : subbody + subsize]
            count = struct.unpack_from("<H", icon, 4)[0]
            for entry_index in range(count):
                off = 6 + entry_index * 16
                width_byte, height_byte, _, _, hx, hy, length, image_off = struct.unpack_from("<4B2H2I", icon, off)
                width = 256 if width_byte == 0 else width_byte
                height = 256 if height_byte == 0 else height_byte
                dib = icon[image_off : image_off + length]
                bit_count = struct.unpack_from("<H", dib, 14)[0]
                if bit_count not in (24, 32):
                    fail(f"{Path(path).name} contains unsupported resource depth {bit_count}")
                color_stride = ((width*bit_count+31)//32)*4
                mask_stride = ((width+31)//32)*4
                pixels = dib[40 : 40 + color_stride * height]
                mask = dib[40+color_stride*height : 40+(color_stride+mask_stride)*height]
                def a_at(x, y):
                    if bit_count == 32:
                        return pixels[(height-1-y)*color_stride+x*4+3]
                    byte = mask[(height-1-y)*mask_stride+x//8]
                    return 0 if byte & (0x80 >> (x%8)) else 255
                if any(a_at(x, y) for x, y in ((0, 0), (width - 1, 0), (0, height - 1), (width - 1, height - 1))):
                    corner_violations.append([frame_index, width, height])
                edge_count = 0
                for x in range(width):
                    edge_count += 1 if a_at(x, 0) else 0
                    edge_count += 1 if a_at(x, height - 1) else 0
                for y in range(height):
                    edge_count += 1 if a_at(0, y) else 0
                    edge_count += 1 if a_at(width - 1, y) else 0
                if edge_count:
                    edge_violations.append([frame_index, width, height, edge_count])
                if a_at(hx, hy) == 0:
                    transparent_hotspots.append([frame_index, width, height, hx, hy])
    return corner_violations, edge_violations, transparent_hotspots


def declared_hotspots(path):
    data = Path(path).read_bytes()
    for tag, body, size in riff_chunks(data, 12, len(data)):
        if tag != b'LIST' or data[body:body+4] != b'fram':
            continue
        for subtag, subbody, subsize in riff_chunks(data, body+4, body+size):
            if subtag != b'icon':
                continue
            icon = data[subbody:subbody+subsize]
            count = struct.unpack_from('<H', icon, 4)[0]
            result = {}
            for index in range(count):
                width, height, _, _, hx, hy, _, _ = struct.unpack_from('<4B2H2I', icon, 6+index*16)
                result[256 if width == 0 else width] = [hx, hy]
            return result
    fail('No embedded cursor hotspots')


def icon_info(user32, gdi32, handle):
    info = ICONINFO()
    if not user32.GetIconInfo(handle, ctypes.byref(info)):
        fail("GetIconInfo failed")
    bitmap = BITMAP()
    if info.hbmColor:
        gdi32.GetObjectW(info.hbmColor, ctypes.sizeof(bitmap), ctypes.byref(bitmap))
        width, height = bitmap.bmWidth, bitmap.bmHeight
    else:
        gdi32.GetObjectW(info.hbmMask, ctypes.sizeof(bitmap), ctypes.byref(bitmap))
        width, height = bitmap.bmWidth, bitmap.bmHeight // 2
    if info.hbmMask:
        gdi32.DeleteObject(info.hbmMask)
    if info.hbmColor:
        gdi32.DeleteObject(info.hbmColor)
    return {"width": width, "height": height, "hotspot": [info.xHotspot, info.yHotspot]}


def draw_icon(user32, gdi32, handle, size, color, step=0):
    hdc = gdi32.CreateCompatibleDC(0)
    bmi = bytearray(40)
    import struct

    struct.pack_into("<IiiHHIIIIII", bmi, 0, 40, size, -size, 1, 32, 0, 0, 0, 0, 0, 0)
    bits = ctypes.c_void_p()
    hbmp = gdi32.CreateDIBSection(hdc, bytes(bmi), 0, ctypes.byref(bits), 0, 0)
    old = gdi32.SelectObject(hdc, hbmp)
    if color == 'checker':
        for top in range(0, size, 8):
            for left in range(0, size, 8):
                brush = gdi32.CreateSolidBrush(0xEEEEEE if (left//8+top//8)%2 else 0x777777)
                rect = (ctypes.c_long * 4)(left, top, min(left+8, size), min(top+8, size))
                user32.FillRect(hdc, ctypes.byref(rect), brush)
                gdi32.DeleteObject(brush)
    else:
        brush = gdi32.CreateSolidBrush(color)
        rect = (ctypes.c_long * 4)(0, 0, size, size)
        user32.FillRect(hdc, ctypes.byref(rect), brush)
        gdi32.DeleteObject(brush)
    if not user32.DrawIconEx(hdc, 0, 0, handle, size, size, step, 0, 3):
        fail("DrawIconEx failed")
    gdi32.GdiFlush()
    buf = (ctypes.c_ubyte * (size * size * 4)).from_address(bits.value)
    im = Image.frombytes("RGBA", (size, size), bytes(buf), "raw", "BGRA")
    gdi32.SelectObject(hdc, old)
    gdi32.DeleteObject(hbmp)
    gdi32.DeleteDC(hdc)
    return im


def validate_pack(folder):
    folder = Path(folder)
    user32 = ctypes.windll.user32
    gdi32 = ctypes.windll.gdi32
    user32.LoadImageW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_uint, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
    user32.LoadImageW.restype = ctypes.c_void_p
    user32.DestroyIcon.argtypes = [ctypes.c_void_p]
    user32.DrawIconEx.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]
    user32.DrawIconEx.restype = ctypes.c_bool
    user32.FillRect.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
    gdi32.GetObjectW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
    gdi32.GetObjectW.restype = ctypes.c_int
    gdi32.DeleteObject.argtypes = [ctypes.c_void_p]
    gdi32.SelectObject.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    gdi32.SelectObject.restype = ctypes.c_void_p
    gdi32.CreateCompatibleDC.argtypes = [ctypes.c_void_p]
    gdi32.CreateCompatibleDC.restype = ctypes.c_void_p
    gdi32.CreateDIBSection.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p, ctypes.c_uint]
    gdi32.CreateDIBSection.restype = ctypes.c_void_p
    gdi32.CreateSolidBrush.argtypes = [ctypes.c_uint32]
    gdi32.CreateSolidBrush.restype = ctypes.c_void_p
    gdi32.DeleteDC.argtypes = [ctypes.c_void_p]
    gdi32.GdiFlush.argtypes = []

    ani_files = sorted(folder.glob("*.ani"))
    max_frames = max(ani_frame_info(path)[0] for path in ani_files)
    native_dir = folder / "native_previews"
    native_dir.mkdir(exist_ok=True)
    transparent_dir = folder / 'native_transparent_previews'
    transparent_dir.mkdir(exist_ok=True)
    browser_dir = folder / 'browser_cursors'
    browser_dir.mkdir(exist_ok=True)
    sheets = {
        size: Image.new("RGB", (112 + max_frames * size, len(ani_files) * (size + 36)), "#353535")
        for size in (32, 64)
    }
    backgrounds = {'dark': 0x291B21, 'white': 0xFFFFFF, 'gray': 0xF3F3F3, 'blue': 0xD8640A, 'checker': 'checker'}
    background_sheets = {size: Image.new('RGB', (112+5*(size+32), 36+len(ani_files)*(size+20)), '#211b29') for size in (32, 64)}
    for size, sheet in background_sheets.items():
        for column, label in enumerate(backgrounds):
            ImageDraw.Draw(sheet).text((112+column*(size+32), 12), label, fill='white')

    results = {}
    for row, path in enumerate(ani_files):
        role = path.stem
        frame_count, jiffies = ani_frame_info(path)
        corner_violations, edge_violations, transparent_hotspots = embedded_alpha_checks(path)
        if corner_violations:
            fail(f"{path.name} has opaque corner pixels in embedded resources: {corner_violations[:3]}")
        if edge_violations or transparent_hotspots:
            fail(f"{path.name} has clipped edges or transparent contacts: {edge_violations[:3]}, {transparent_hotspots[:3]}")
        results[role] = {"embedded_transparent_hotspots": transparent_hotspots, "embedded_edge_pixels": edge_violations}
        expected_hotspots = declared_hotspots(path)
        for size in (32, 48, 64):
            handle = user32.LoadImageW(None, str(path), 2, size, size, 0x10)
            if not handle:
                fail(f"LoadImageW failed for {path.name} at {size}px")
            info = icon_info(user32, gdi32, handle)
            if info['hotspot'] != expected_hotspots[size]:
                user32.DestroyIcon(handle)
                fail(f'{path.name} native {size}px hotspot {info["hotspot"]} differs from declared {expected_hotspots[size]}')
            previews = []
            transparent_frames = []
            contact_pixels = []
            rendered_for_uniqueness = []
            for step in range(frame_count):
                white = draw_icon(user32, gdi32, handle, size, 0xFFFFFF, step=step).convert("RGB")
                black = draw_icon(user32, gdi32, handle, size, 0, step=step).convert('RGB')
                white_array, black_array = np.array(white, dtype=np.int16), np.array(black, dtype=np.int16)
                transmission = white_array-black_array
                clear = np.all(transmission == 255, axis=2)
                opaque = np.all(transmission == 0, axis=2)
                if not np.all(clear | opaque):
                    fail(f'{path.name} frame {step} native {size}px has partial effective opacity')
                rgba = np.zeros((size, size, 4), dtype=np.uint8)
                rgba[:, :, :3] = black_array.astype(np.uint8)
                rgba[:, :, 3] = np.where(opaque, 255, 0)
                if np.any(rgba[0, :, 3]) or np.any(rgba[-1, :, 3]) or np.any(rgba[:, 0, 3]) or np.any(rgba[:, -1, 3]):
                    fail(f'{path.name} frame {step} native {size}px touches the canvas edge')
                hx, hy = info['hotspot']
                if rgba[hy, hx, 3] != 255:
                    fail(f'{path.name} frame {step} native {size}px contact {(hx,hy)} is transparent')
                contact_pixels.append(tuple(int(v) for v in rgba[hy, hx]))
                transparent_frames.append(Image.fromarray(rgba))
                rendered_for_uniqueness.append(white.tobytes())
                if size in (32, 64):
                    previews.append(white)
                    sheets[size].paste(white, (112 + step * size, row * (size + 36) + 25))
            if size in background_sheets:
                contact_sheet = background_sheets[size]
                ImageDraw.Draw(contact_sheet).text((4, 36+row*(size+20)), role, fill='white')
                for column, color in enumerate(backgrounds.values()):
                    rendered = draw_icon(user32, gdi32, handle, size, color, step=0).convert('RGB')
                    contact_sheet.paste(rendered, (112+column*(size+32), 36+row*(size+20)))
            user32.DestroyIcon(handle)
            if info["width"] != size or info["height"] != size:
                fail(f"{path.name} loaded {info['width']}x{info['height']} for requested {size}")
            unique_frames = len(set(rendered_for_uniqueness))
            if len(set(contact_pixels)) != 1:
                fail(f'{path.name} native {size}px contact pixel changes between frames')
            results[role][str(size)] = {**info, "frames_rendered": frame_count, "unique_native_frames": unique_frames,
                                      'native_hotspot_matches_embedded': True,
                                      'native_hotspot_alpha': 255, 'native_contact_pixel_fixed': True,
                                      'native_edge_pixels': 0, 'native_partial_opacity_pixels': 0}
            generate_animated_gif(transparent_frames, str(transparent_dir/f'{role}_{size}px.gif'),
                                  scale_factor=1, jiffies=jiffies)
            if size in (32,64):
                transparent_frames[0].save(browser_dir/f'{role}_{size}px.png')
            if size in (32, 64):
                ImageDraw.Draw(sheets[size]).text((4, row * (size + 36) + 25), role, fill="white")
                generate_animated_gif(previews, str(native_dir / f'{role}_{size}px.gif'),
                                      scale_factor=1, jiffies=jiffies)
                if size == 64:
                    generate_animated_gif(previews, str(native_dir / f'{role}.gif'),
                                          scale_factor=1, jiffies=jiffies)
    for size, sheet in sheets.items():
        sheet.save(folder / f"windows_render_check_{size}px.png")
    sheets[64].save(folder / "windows_render_check.png")
    for size, sheet in background_sheets.items():
        sheet.save(folder / f'native_backgrounds_{size}px.png')
    output = folder / "muse_native_validation.json"
    output.write_text(json.dumps(results, indent=2), encoding="utf-8")
    return results, output


def main():
    results, output = validate_pack(sys.argv[1])
    print(f"validated {len(results)} cursors at 32/48/64px")
    print(output)


if __name__ == "__main__":
    main()
