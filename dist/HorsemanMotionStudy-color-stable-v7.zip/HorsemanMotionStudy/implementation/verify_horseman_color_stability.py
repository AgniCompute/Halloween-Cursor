"""Verify actual delivered GIF colors, coverage and timing without equipping."""
import hashlib
import contextlib
import io
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
from PIL import Image, ImageDraw, ImageSequence

import check_horseman_color as native
from engine.preview_gen import generate_animated_gif

ROOT = Path(__file__).resolve().parent


def decoded(path):
    with Image.open(path) as animation:
        frames = [np.array(frame.convert('RGBA')) for frame in ImageSequence.Iterator(animation)]
        delays = [frame.info['duration'] for frame in ImageSequence.Iterator(animation)]
    return np.stack(frames), delays


def fixed_pixel_changes(source, preview):
    fixed = np.all(source == source[0], axis=(0, 3)) & (source[0, :, :, 3] == 255)
    changing = fixed & np.any(preview != preview[0], axis=(0, 3))
    return int(fixed.sum()), int(changing.sum())


def synthetic_regression():
    """A moving gold effect must not recolor a still purple patch or black ink."""
    frames = []
    for step in range(12):
        frame = Image.new('RGBA', (32, 32))
        draw = ImageDraw.Draw(frame)
        draw.rectangle((3, 3, 8, 8), fill=(63, 25, 72, 255))
        draw.rectangle((12, 3, 16, 8), fill=(0, 0, 0, 255))
        draw.ellipse((step, 17, step + 8, 25), fill=(255, 150 + step * 7, 31, 255))
        frames.append(frame)
    with TemporaryDirectory(dir=ROOT) as temporary:
        path = Path(temporary) / 'regression.gif'
        generate_animated_gif(frames, str(path), scale_factor=1, jiffies=2)
        actual, delays = decoded(path)
        source = np.stack([np.array(frame) for frame in frames])
        fixed, changes = fixed_pixel_changes(source, actual)
        assert changes == 0 and fixed > 40
        assert np.array_equal(source[:, :, :, 3], actual[:, :, :, 3])
        assert np.all(actual[:, 3:9, 12:17, :3] == 0)
        assert np.all(actual[:, 3:9, 12:17, 3] == 255)
        assert sum(delays) == 400
        generate_animated_gif([Image.new('RGBA', (3, 3))], str(path), scale_factor=1)
        blank, _ = decoded(path)
        assert not blank[:, :, :, 3].any()
    return {'fixed_opaque_pixels': fixed, 'changing_fixed_pixels': changes,
            'opaque_black_preserved': True, 'clear_frame_preserved': True, 'loop_ms': 400}


def check_pack(name):
    pack = ROOT / 'cursor_sets' / name
    evidence = pack / 'audits' / 'color_stability'
    baseline = evidence / 'before'
    with contextlib.redirect_stdout(io.StringIO()):
        report = native.inspect(pack, evidence / 'after')
    report['fixed_pixels'] = {}
    report['color_only_reference_masks_unchanged'] = True
    report['previous_delivered_mask_changes'] = {}
    for role in native.ROLES:
        current = sorted((pack / 'sources').glob(f'{role}_*.png'))
        previous = sorted((baseline / 'sources').glob(f'{role}_*.png'))
        assert len(current) == len(previous)
        mask_reference = previous
        if name == 'HorsemanMotionStudy' and role == 'busy':
            # MotionStudy's delivered gallop predates the already-authored
            # foreleg update. Stomp's before snapshot contains that geometry.
            reference = ROOT / 'cursor_sets' / 'HorsemanStompStudy' / 'audits' / 'color_stability' / 'before'
            mask_reference = sorted((reference / 'sources').glob('busy_*.png'))
        changed_frames = changed_pixels = 0
        for new_path, old_path, reference_path in zip(current, previous, mask_reference):
            new, old = np.array(Image.open(new_path)), np.array(Image.open(old_path))
            reference = np.array(Image.open(reference_path))
            difference = int(np.count_nonzero(new[:, :, 3] != old[:, :, 3]))
            changed_frames += int(difference > 0)
            changed_pixels += difference
            assert np.array_equal(new[:, :, 3], reference[:, :, 3]), (role, new_path.name, 'color altered mask')
        report['previous_delivered_mask_changes'][role] = {'frames': changed_frames, 'pixels': changed_pixels,
            'reference': 'Stomp pre-color gallop with current foreleg anatomy' if mask_reference is not previous else 'own delivered baseline'}
        for size in (32, 48, 64):
            source = np.stack([np.array(Image.open(path)) for path in
                               sorted((evidence / 'after' / f'{role}_native{size}').glob('*.png'))])
            preview, delays = decoded(pack / 'native_transparent_previews' / f'{role}_{size}px.gif')
            fixed, changed = fixed_pixel_changes(source, preview)
            assert changed == 0, (name, role, size, changed)
            assert sum(delays) == round(report['roles'][role]['loop_ms'])
            report['fixed_pixels'][f'{role}_{size}'] = {'fixed_opaque_pixels': fixed,
                                                       'changing_fixed_pixels': changed}
            if size == 64:
                old_source = np.stack([np.array(Image.open(path)) for path in previous])
                old_gif, _ = decoded(baseline / 'native_transparent_previews' / f'{role}_{size}px.gif')
                old_fixed, old_changed = fixed_pixel_changes(old_source, old_gif)
                report['fixed_pixels'][f'{role}_{size}']['before'] = {
                    'fixed_opaque_pixels': old_fixed, 'changing_fixed_pixels': old_changed}
    # Both packs share the exact same delivered gallop and default arrow bytes.
    other = ROOT / 'cursor_sets' / ('HorsemanMotionStudy' if name == 'HorsemanStompStudy' else 'HorsemanStompStudy')
    for role in ('pointer', 'busy'):
        assert (pack / f'{role}.ani').read_bytes() == (other / f'{role}.ani').read_bytes()
    # Inspect all preview routes, including white-background native GIFs and the
    # combined comparison, rather than only the transparent card animations.
    report['gif_metadata'] = {}
    identity = json.loads((pack / 'build_identity.json').read_text())
    paths = [pack / name for name in identity['preview_files'] if name.endswith('.gif')] + [pack / 'review.gif']
    if name == 'HorsemanStompStudy':
        paths.append(pack / 'stomp-rich-color.gif')
    for path in paths:
        animation, delays = decoded(path)
        role = path.stem.split('_')[0]
        expected_loop = 1600 if role in ('review', 'stomp-rich-color') else round(report['roles'][role]['loop_ms'])
        assert sum(delays) == expected_loop, (path, delays)
        report['gif_metadata'][path.relative_to(pack).as_posix()] = {
            'frames': len(animation), 'size': [animation.shape[2], animation.shape[1]],
            'loop_ms': sum(delays), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    report['same_context_registry_snapshot_unchanged'] = native.scheme_state() == json.loads((baseline / 'scheme_state.json').read_text())
    assert report['same_context_registry_snapshot_unchanged']
    report['registry_scope_note'] = 'Same restricted-process context only; no equipped-scheme writes or refresh performed.'
    report['synthetic_regression'] = synthetic_regression()
    (evidence / 'color_stability_checks.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(f'PASS {name}: {len(paths)} GIFs; all fixed native pixels stable at 32/48/64; color-only masks unchanged.')
    return report


if __name__ == '__main__':
    for name in ('HorsemanStompStudy', 'HorsemanMotionStudy'):
        check_pack(name)
