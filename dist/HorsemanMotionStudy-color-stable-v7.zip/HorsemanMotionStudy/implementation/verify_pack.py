"""Render forced ANI frame indices; automatic playback is not verified."""
import ctypes as c
from ctypes import wintypes as w
import json
from pathlib import Path
import struct
from PIL import Image, ImageDraw
import numpy as np


def riff_chunks(data,start,end):
    chunks=[]
    while start<end:
        if start+8>end:
            raise ValueError('Truncated RIFF header')
        tag,length=struct.unpack_from('<4sI',data,start)
        stop=start+8+length
        if stop>end:
            raise ValueError('Truncated RIFF payload')
        chunks.append((tag,data[start+8:stop]))
        start=stop+(length&1)
    return chunks


def check_alpha_resource(u,g,folder):
    """Catch double alpha multiplication in a disk CUR resource with native loading."""
    from engine.ani_compiler import make_cur_binary
    probe=Image.new('RGBA',(64,64))
    ImageDraw.Draw(probe).rectangle((16,16,47,47),fill=(255,0,0,128))
    artifact_dir=folder/'validation_artifacts'
    artifact_dir.mkdir(exist_ok=True)
    path=artifact_dir/'alpha_encoding_probe.cur'
    path.write_bytes(make_cur_binary(probe,32,32))
    handle=u.LoadImageW(None,str(path),2,64,64,0x10)
    if not handle:
        raise c.WinError(c.get_last_error())
    dc=g.CreateCompatibleDC(None)
    info=c.create_string_buffer(struct.pack('<IiiHHIIiiII',40,64,-64,1,32,0,16384,0,0,0,0))
    bits=c.c_void_p()
    bitmap=g.CreateDIBSection(dc,info,0,c.byref(bits),None,0)
    old=g.SelectObject(dc,bitmap)
    samples=[]
    try:
        for bg in (0,255):
            c.memset(bits,bg,16384)
            assert u.DrawIconEx(dc,0,0,handle,64,64,0,None,3)
            g.GdiFlush()
            rgb=Image.frombytes('RGBA',(64,64),c.string_at(bits,16384),'raw','BGRA').convert('RGB')
            actual=rgb.getpixel((32,32))
            expected=(128,0,0) if bg==0 else (255,127,127)
            assert max(abs(a-b) for a,b in zip(actual,expected))<=2, ('Double alpha multiplication',bg,actual,expected)
            samples.append(dict(background=bg,actual=actual,expected=expected))
    finally:
        g.SelectObject(dc,old); g.DeleteObject(bitmap); g.DeleteDC(dc); u.DestroyCursor(handle)
    (folder/'alpha_validation.json').write_text(json.dumps(dict(passed=True,samples=samples),indent=2))


def verify_pack(folder, expected_frames=None, minimum_unique_frames=12, resource_loader=False, require_disk_fidelity=False):
    u = c.WinDLL('user32', use_last_error=True)
    g = c.WinDLL('gdi32', use_last_error=True)
    u.LoadCursorFromFileW.argtypes = [w.LPCWSTR]
    u.LoadCursorFromFileW.restype = w.HANDLE
    u.LoadImageW.argtypes=[w.HINSTANCE,w.LPCWSTR,w.UINT,c.c_int,c.c_int,w.UINT]
    u.LoadImageW.restype=w.HANDLE
    u.CreateIconFromResourceEx.argtypes=[c.c_void_p,w.DWORD,w.BOOL,w.DWORD,c.c_int,c.c_int,w.UINT]
    u.CreateIconFromResourceEx.restype=w.HANDLE
    u.DestroyCursor.argtypes = [w.HANDLE]
    u.DrawIconEx.argtypes = [w.HDC, c.c_int, c.c_int, w.HANDLE, c.c_int,
                             c.c_int, w.UINT, w.HBRUSH, w.UINT]
    g.CreateCompatibleDC.argtypes = [w.HDC]
    g.CreateCompatibleDC.restype = w.HDC
    g.CreateDIBSection.argtypes = [w.HDC, c.c_void_p, w.UINT,
                                  c.POINTER(c.c_void_p), w.HANDLE, w.DWORD]
    g.CreateDIBSection.restype = w.HBITMAP
    g.SelectObject.argtypes = [w.HDC, w.HANDLE]
    g.SelectObject.restype = w.HANDLE
    g.DeleteObject.argtypes = [w.HANDLE]
    g.DeleteDC.argtypes = [w.HDC]
    g.GdiFlush.argtypes = []
    class ICONINFO(c.Structure):
        _fields_=[('fIcon',w.BOOL),('xHotspot',w.DWORD),('yHotspot',w.DWORD),
                  ('hbmMask',w.HBITMAP),('hbmColor',w.HBITMAP)]
    class BITMAP(c.Structure):
        _fields_=[('bmType',w.LONG),('bmWidth',w.LONG),('bmHeight',w.LONG),
                  ('bmWidthBytes',w.LONG),('bmPlanes',w.WORD),('bmBitsPixel',w.WORD),('bmBits',c.c_void_p)]
    u.GetIconInfo.argtypes=[w.HANDLE,c.POINTER(ICONINFO)]
    u.GetIconInfo.restype=w.BOOL
    g.GetObjectW.argtypes=[w.HANDLE,c.c_int,c.c_void_p]
    g.GetObjectW.restype=c.c_int
    def cursor_info(handle):
        info=ICONINFO()
        if not u.GetIconInfo(handle,c.byref(info)):
            raise c.WinError(c.get_last_error())
        try:
            bitmap_info=BITMAP()
            target=info.hbmColor or info.hbmMask
            if not g.GetObjectW(target,c.sizeof(bitmap_info),c.byref(bitmap_info)):
                raise c.WinError(c.get_last_error())
            return dict(width=bitmap_info.bmWidth,
                        height=bitmap_info.bmHeight if info.hbmColor else bitmap_info.bmHeight//2,
                        hotspot=[info.xHotspot,info.yHotspot])
        finally:
            for owned_bitmap in (info.hbmMask,info.hbmColor):
                if owned_bitmap:
                    g.DeleteObject(owned_bitmap)
    folder = Path(folder).resolve()
    check_alpha_resource(u,g,folder)
    maximum_frames = max(struct.unpack('<9I',dict(riff_chunks(p.read_bytes(),12,len(p.read_bytes())))[b'anih'])[1]
                         for p in folder.glob('*.ani'))
    sheets = {size: Image.new('RGB', (112 + maximum_frames * size, 17 * (size+36)), '#353535') for size in (32,64)}
    sheet = sheets[64]
    draw = ImageDraw.Draw(sheet)
    report = []
    for row, path in enumerate(sorted(folder.glob('*.ani'))):
        data = path.read_bytes()
        assert data[:4] == b'RIFF' and struct.unpack_from('<I', data, 4)[0] == len(data)-8
        chunks=dict(riff_chunks(data,12,len(data)))
        header = struct.unpack('<9I', chunks[b'anih'])
        count = header[1]
        assert header[2]==count and header[7]>0 and header[8]==1
        icons=riff_chunks(chunks[b'LIST'],4,len(chunks[b'LIST']))
        assert chunks[b'LIST'][:4]==b'fram' and len(icons)==count
        hotspots=[]
        hotspot_opacity=[]
        resource_payloads=[]
        for tag,icon in icons:
            reserved,kind,resource_count=struct.unpack_from('<3H',icon)
            assert tag==b'icon' and reserved==0 and kind==2 and resource_count in (1,3)
            width,height,_,_,hx,hy,length,offset=struct.unpack_from('<4B2H2I',icon,6)
            assert (width,height)==(64,64) and offset>=6+resource_count*16 and offset+length<=len(icon)
            assert hx<width and hy<height
            # CUR DIB pixels are bottom-up straight BGRA; Windows premultiplies.
            dib=icon[offset:offset+length]
            dib_size,dib_width,dib_height=struct.unpack_from('<Iii',dib)
            assert (dib_size,dib_width,dib_height)==(40,64,128)
            depth=struct.unpack_from('<H',dib,14)[0]
            assert depth in (24,32)
            if depth==32:
                bitmap=np.frombuffer(dib[40:40+64*64*4],dtype=np.uint8).reshape(64,64,4)[::-1]
            else:
                bitmap=np.zeros((64,64,4),dtype=np.uint8)
                bitmap[:,:,:3]=np.frombuffer(dib[40:40+64*64*3],dtype=np.uint8).reshape(64,64,3)[::-1]
                mask=np.frombuffer(dib[40+64*64*3:40+64*64*3+64*8],dtype=np.uint8).reshape(64,8)[::-1]
                bitmap[:,:,3]=np.where(np.unpackbits(mask,axis=1)==0,255,0)
            hotspot_opacity.append(int(bitmap[hy,hx,3]))
            assert bitmap[hy,hx,3]>128,(path.name,'Contact point is transparent')
            if expected_frames is not None:
                source=np.asarray(expected_frames[path.stem][len(hotspots)],dtype=np.uint16)
                expected=np.empty((64,64,4),dtype=np.uint8)
                expected[:,:,:3]=source[:,:,2::-1].astype(np.uint8)
                expected[:,:,3]=source[:,:,3]
                if depth==24:
                    expected[expected[:,:,3]==0,:3]=0
                assert np.array_equal(bitmap,expected),(path.name,'Encoded pixels differ from source')
            hotspots.append((hx,hy))
            resource_payloads.append(struct.pack('<HH',hx,hy)+dib)
        assert len(set(hotspots))==1, 'Animation hotspots must remain fixed'
        # Each requested size is independently loaded, never a scaled 64px handle.
        handles={}
        try:
            for size in (32,64):
                if resource_loader:
                    resource_buffer=c.create_string_buffer(data)
                    handles[size]=u.CreateIconFromResourceEx(resource_buffer,len(data),False,0x30000,size,size,0)
                else:
                    handles[size]=u.LoadImageW(None,str(path),2,size,size,0x10)
                if not handles[size]:
                    raise c.WinError(c.get_last_error())
            default_handle=u.LoadCursorFromFileW(str(path))
            if not default_handle:
                raise c.WinError(c.get_last_error())
        except Exception:
            for loaded in handles.values():
                if loaded:
                    u.DestroyCursor(loaded)
            raise
        dc = g.CreateCompatibleDC(None)
        info = c.create_string_buffer(struct.pack('<IiiHHIIiiII',40,64,-64,1,32,0,16384,0,0,0,0))
        bits = c.c_void_p()
        bitmap = g.CreateDIBSection(dc, info, 0, c.byref(bits), None, 0)
        old = g.SelectObject(dc, bitmap)
        rendered = []
        source_error=0
        minimum = 4096
        background_results=[]
        native_previews={32:[],64:[]}
        opacity_results=[]
        default_rendered=[]
        default_background_results=[]
        default_opacity_results=[]
        loaded_info={size:cursor_info(loaded) for size,loaded in handles.items()}
        default_info=cursor_info(default_handle)
        direct_resource_error=0
        checker=np.array([[(230,230,230,255) if (x//8+y//8)%2 else (45,45,45,255)
                           for x in range(64)] for y in range(64)],dtype=np.uint8)
        try:
            if expected_frames is not None:
                for step,payload in enumerate(resource_payloads):
                    buffer=c.create_string_buffer(payload)
                    resource_cursor=u.CreateIconFromResourceEx(buffer,len(payload),False,0x30000,64,64,0)
                    if not resource_cursor:
                        raise c.WinError(c.get_last_error())
                    try:
                        c.memset(bits,255,16384)
                        assert u.DrawIconEx(dc,0,0,resource_cursor,64,64,0,None,3)
                        g.GdiFlush()
                        rgb=Image.frombytes('RGBA',(64,64),c.string_at(bits,16384),'raw','BGRA').convert('RGB')
                        expected=Image.new('RGBA',(64,64),'white')
                        expected.alpha_composite(expected_frames[path.stem][step])
                        error=np.abs(np.asarray(rgb,dtype=np.int16)-np.asarray(expected.convert('RGB'),dtype=np.int16))
                        direct_resource_error=max(direct_resource_error,int(error.max()))
                        assert error.max()<=2,(path.name,step,'Direct CUR resource compositing differs from source')
                    finally:
                        u.DestroyCursor(resource_cursor)
            for step in range(count):
                for size in (32,64):
                    opacity_samples={}
                    for bg in (0,255,'checker'):
                        if bg=='checker':
                            c.memmove(bits,checker.tobytes(),16384)
                        else:
                            c.memset(bits,bg,16384)
                        baseline=np.frombuffer(c.string_at(bits,16384),dtype=np.uint8).reshape(64,64,4).copy()
                        if not u.DrawIconEx(dc,0,0,handles[size],size,size,step,None,3):
                            raise c.WinError(c.get_last_error())
                        g.GdiFlush()
                        pixels=c.string_at(bits,16384)
                        actual=np.frombuffer(pixels,dtype=np.uint8).reshape(64,64,4)
                        if require_disk_fidelity and size==64 and expected_frames is not None:
                            expected_bg=Image.fromarray(baseline[:,:,2::-1]).convert('RGBA')
                            expected_bg.alpha_composite(expected_frames[path.stem][step])
                            channel_error=np.abs(actual[:,:,2::-1].astype(np.int16)-np.asarray(expected_bg.convert('RGB'),dtype=np.int16))
                            assert channel_error.max()<=2,(path.name,step,bg,'Disk loader differs from source',int(channel_error.max()),np.unravel_index(channel_error.argmax(),channel_error.shape))
                            source_error=max(source_error,int(channel_error.max()))
                        visible=int(np.any(actual[:size,:size,:3]!=baseline[:size,:size,:3],axis=2).sum())
                        minimum=min(minimum,visible)
                        assert visible>size//2,(path.name,step,'invisible frame')
                        if step==0:
                            background_results.append(dict(size=size,background=bg,visible_pixels=visible))
                        rgb=Image.frombytes('RGBA',(64,64),pixels,'raw','BGRA').convert('RGB')
                        if bg in (0,255):
                            opacity_samples[bg]=actual[:size,:size,:3].astype(np.int16).copy()
                        if bg=='checker':
                            native_previews[size].append(rgb.crop((0,0,size,size)))
                        if bg==255:
                            sheets[size].paste(rgb.crop((0,0,size,size)),(112+step*size,row*(size+36)+25))
                        if size==64 and bg==255:
                            if expected_frames is not None:
                                expected=Image.new('RGBA',(64,64),'white')
                                expected.alpha_composite(expected_frames[path.stem][step])
                                error=np.abs(np.asarray(rgb,dtype=np.int16)-np.asarray(expected.convert('RGB'),dtype=np.int16))
                                source_error=max(source_error,int(error.max()))
                            rendered.append(rgb.tobytes())
                            sheet.paste(rgb,(112+step*64,row*100+25))
                    # Dual backgrounds recover transmission independently of source resampling.
                    transmission=opacity_samples[255]-opacity_samples[0]
                    mixed=int(np.any((transmission>2)&(transmission<253),axis=2).sum())
                    opacity_results.append(dict(size=size,step=step,partial_alpha_pixels=mixed))
                    if require_disk_fidelity:
                        assert mixed==0,(path.name,step,size,'Opaque disk cursor has partial effective opacity',mixed)
                # Draw at the dimensions reported by the default loader, not assumed metrics.
                default_size=default_info['width']
                default_height=default_info['height']
                assert 0<default_size<=64 and 0<default_height<=64,('Unsupported default cursor size',default_info)
                default_samples={}
                for bg in (0,255,'checker'):
                    if bg=='checker':
                        c.memmove(bits,checker.tobytes(),16384)
                    else:
                        c.memset(bits,bg,16384)
                    baseline=np.frombuffer(c.string_at(bits,16384),dtype=np.uint8).reshape(64,64,4).copy()
                    assert u.DrawIconEx(dc,0,0,default_handle,default_size,default_height,step,None,3)
                    g.GdiFlush()
                    actual=np.frombuffer(c.string_at(bits,16384),dtype=np.uint8).reshape(64,64,4).copy()
                    visible=int(np.any(actual[:default_height,:default_size,:3]!=baseline[:default_height,:default_size,:3],axis=2).sum())
                    assert visible>default_size//2,(path.name,step,bg,'Default file loader invisible')
                    default_background_results.append(dict(step=step,background=bg,visible_pixels=visible))
                    if bg in (0,255):
                        default_samples[bg]=actual[:default_height,:default_size,:3].astype(np.int16)
                    if bg==255:
                        default_rendered.append(actual[:default_height,:default_size,:3].tobytes())
                transmission=default_samples[255]-default_samples[0]
                mixed=int(np.any((transmission>2)&(transmission<253),axis=2).sum())
                default_opacity_results.append(dict(step=step,partial_alpha_pixels=mixed))
                if require_disk_fidelity:
                    assert mixed==0,(path.name,step,'Default file loader has partial effective opacity',mixed)
            required_unique=(minimum_unique_frames.get(path.stem,12) if isinstance(minimum_unique_frames,dict) else minimum_unique_frames)
            assert len(set(rendered)) >= min(required_unique,count), (path.name,'Too few distinct native frames')
            differences=[int(np.any(np.frombuffer(rendered[i],dtype=np.uint8).reshape(64,64,3)!=
                                   np.frombuffer(rendered[(i+1)%count],dtype=np.uint8).reshape(64,64,3),axis=2).sum())
                         for i in range(count)]
            report.append(dict(file=path.name,frames=count,unique_windows_frames=len(set(rendered)),
                               minimum_visible_pixels=minimum,default_jiffies=header[7],hotspot=hotspots[0],minimum_hotspot_alpha=min(hotspot_opacity),
                               adjacent_frame_changed_pixels=differences,background_checks=background_results,
                               independently_loaded_sizes=[32,64],
                               loaded_cursor_info=loaded_info,
                               default_file_loader_cursor_info=default_info,
                               default_file_loader_background_checks=default_background_results,
                               default_file_loader_effective_opacity_checks=default_opacity_results,
                               default_file_loader_binary_opacity_verified=require_disk_fidelity,
                               native_animation_loader='CreateIconFromResourceEx full ANI' if resource_loader else 'LoadImageW file',
                               effective_opacity_checks=opacity_results,
                               binary_effective_opacity_verified=require_disk_fidelity,
                               default_file_loader_frames_checked=len(default_rendered),
                               default_file_loader_draw_size=default_size,
                               default_file_loader_unique_frames=len(set(default_rendered)),
                               size32_source_resampling_fidelity_verified=False,
                               automatic_equipped_playback_verified=False,
                               fluid_motion_quality_verified=False))
            if expected_frames is not None:
                report[-1]['maximum_source_render_channel_difference']=source_error
                if resource_loader or require_disk_fidelity:
                    assert source_error<=2,(path.name,'Native ANI rendering differs from source',source_error)
                report[-1]['disk_loader_source_fidelity_verified']=require_disk_fidelity and not resource_loader
                report[-1]['native_animation_loader']='CreateIconFromResourceEx full ANI' if resource_loader else 'LoadImageW file'
                report[-1]['embedded_source_pixel_encoding_verified']=True
                report[-1]['maximum_direct_resource_channel_error']=direct_resource_error
                report[-1]['windows_resource_compositing_verified']=True
                report[-1]['source_render_difference_note']=('Full ANI resource loader checked against source; file-loader alpha transform is bypassed in tester.' if resource_loader else 'Opaque ANI frames loaded from disk match prepared sources on black, white and checker backgrounds at64px.' if require_disk_fidelity else 'Identical DIB is correct through CreateIconFromResourceEx; LoadImageW IMAGE_CURSOR transforms some edges. Exact internal transform is unresolved; this metric is not a fidelity pass.')
            from engine.preview_gen import generate_animated_gif
            native_dir=folder/'native_previews'
            native_dir.mkdir(exist_ok=True)
            for size in (32,64):
                previews=native_previews[size]
                generate_animated_gif(previews, str(native_dir/f'{path.stem}_{size}px.gif'),
                                      scale_factor=1, jiffies=header[7])
                ImageDraw.Draw(sheets[size]).text((4,row*(size+36)+25),path.stem,fill='white')
            # Keep the previous preview name for existing callers; frames are actual-size.
            generate_animated_gif(native_previews[64], str(native_dir/f'{path.stem}.gif'),
                                  scale_factor=1, jiffies=header[7])
        finally:
            g.SelectObject(dc,old)
            g.DeleteObject(bitmap)
            g.DeleteDC(dc)
            for loaded in handles.values():
                u.DestroyCursor(loaded)
            u.DestroyCursor(default_handle)
    for size,native_sheet in sheets.items():
        native_sheet.save(folder/f'windows_render_check_{size}px.png')
    sheet.save(folder/'windows_render_check.png')
    (folder/'validation.json').write_text(json.dumps(report,indent=2))
    print(f'PASS: {len(report)} cursors independently loaded and frame-rendered at 32/64px on black/white/checker backgrounds. Equipped playback not tested.')
    return report


if __name__ == '__main__':
    import sys
    verify_pack(sys.argv[1] if len(sys.argv)>1 else 'cursor_sets/HeadlessHorsemanWindowsTrial')
