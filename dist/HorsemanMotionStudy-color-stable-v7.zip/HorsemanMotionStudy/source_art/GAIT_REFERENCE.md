The previous loop drove upper and lower joints with unrelated angle arrays.
Revision3 instead drives hoof paths: a grounded backward sweep relative to the
left-facing body, a lifted recovery, coordinated contacts, and a suspension
interval. Two-link inverse kinematics connects each hip/shoulder to its ankle.
Hoofs are separate rigid crops of the existing shin art and remain level in
the support phase. This is stylized kinematic animation, not a physical model.

Gallop sequencing reference: trailing hind, leading hind, trailing fore,
leading fore in the research description:
https://www.sciencedirect.com/science/article/pii/S0021929001002238

Forelimb extension in support and flexion after lift-off, from the original
high-speed-filming study (243fps):
https://beva.onlinelibrary.wiley.com/doi/10.1111/j.2042-3306.1994.tb04869.x

Those observations guide the timing and recovery emphasis. This cursor rig
does not reproduce measured horse anatomy or claim gait biomechanics fidelity.
