"""Extract six connected source parts without treating grid cells as poses."""
import json
from collections import deque
from pathlib import Path
import numpy as np
from PIL import Image, ImageFilter

ROOT = Path(__file__).resolve().parent
NAMES = ('body', 'cape', 'tail', 'front_upper', 'rear_upper', 'shin')

def main():
    atlas = Image.open(ROOT/'busy-rig-source.png').convert('RGBA')
    alpha = np.array(atlas.getchannel('A'))
    seen = np.zeros(alpha.shape, bool)
    components = []
    for y, x in zip(*np.where(alpha >= 128)):
        if seen[y, x]:
            continue
        queue, points = deque([(int(x), int(y))]), []
        seen[y, x] = True
        while queue:
            px, py = queue.popleft()
            points.append((px, py))
            for nx, ny in ((px-1,py),(px+1,py),(px,py-1),(px,py+1)):
                if 0 <= nx < atlas.width and 0 <= ny < atlas.height and not seen[ny,nx] and alpha[ny,nx] >= 128:
                    seen[ny,nx] = True
                    queue.append((nx,ny))
        if len(points) > 4000:
            components.append(points)
    assert len(components) == 6, len(components)
    components.sort(key=lambda p: (min(y for x,y in p)>550, min(x for x,y in p)))
    records = []
    for name, points in zip(NAMES, components):
        bounds = (max(0,min(x for x,y in points)-3), max(0,min(y for x,y in points)-3), min(atlas.width,max(x for x,y in points)+4), min(atlas.height,max(y for x,y in points)+4))
        mask = np.zeros(alpha.shape, np.uint8)
        for x,y in points:
            mask[y,x] = 255
        mask = Image.fromarray(mask).filter(ImageFilter.MaxFilter(7))
        part = atlas.copy()
        part.putalpha(Image.composite(atlas.getchannel('A'),Image.new('L',atlas.size),mask))
        part.crop(bounds).save(ROOT/f'{name}.png')
        records.append(dict(name=name, bounds=bounds, source_poses=1))
    (ROOT/'extraction.json').write_text(json.dumps(records,indent=2), encoding='utf-8')
    print(records)

if __name__ == '__main__':
    main()
