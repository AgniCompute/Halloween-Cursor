HORSEMAN STOMP STUDY

A separate three-role proof: stylized default arrow, stomping Horseman link, articulated Horseman busy loop.
Generated source pieces are assembled and moved with a code rig. Composite frames are not independently hand-drawn poses. Flame motion is procedural, not physical simulation.

Open preview.html for actual Windows-rendered 32px and 64px GIFs, 2x inspection, five backgrounds, fixed contact markers, and a still-frame browser aiming test.
ANI files embed 64px, 48px, and 32px resources using 24-bit colour and 1-bit transparency masks.
This proof has no installer and does not modify the existing 17-role pack or equipped cursor scheme.

Native checks load the delivered files and force each DrawIconEx index. These checks verify frame rendering and contacts, not automatic Windows playback or fluid character motion.
Browser target clicks exercise static cursor contacts; automated semantic clicks do not establish human aiming accuracy.
For a temporary native trial, run TRY_HORSEMAN_STOMP.cmd in this folder. Three regions show arrow, stomp and gallop; press 1 for 32px, 2 for 64px, or Esc to close. This uses a window-local cursor and leaves the equipped scheme unchanged. Successful loading alone does not verify automatic playback.
Both horses share fixed source-piece color grading before motion. GIFs use one master palette per loop to keep unchanged pixels steady; moving limbs and fire still change intentionally.
review.gif compares native 32px GIF frames at actual size with native 64px GIF frames enlarged 2x. It uses native-GIF palette colors; the busy loop repeats twice during the 1600ms comparison.
See animation_manifest.json, muse_native_validation.json, validation.json, build_identity.json, native contact sheets, and GIFs for the exact build evidence.
