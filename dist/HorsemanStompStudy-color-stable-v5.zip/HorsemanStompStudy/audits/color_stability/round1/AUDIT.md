# Independent audit: Horseman Stomp Study

**Verdict: accepted, round 1.** No high-severity actionable artwork, motion, encoding, or preview findings remain for `horseman-stomp-color-stable-v5`. This acceptance covers the three proof roles (pointer, link, busy). It does not approve equipping a cursor or certify automatic playback.

## What was independently tested

- Loaded each delivered ANI from disk with Windows `LoadImageW` at 32, 48, and 64 pixels. Forced every `DrawIconEx` index on black and white: 120 indices per size, 360 native frame pairs per pack. Recovered RGBA from the black/white difference and saved all native frames under `native/`.
- Parsed every ANI RIFF/CUR/DIB resource: 24-bit BGR and one-bit AND masks at 32/48/64. Compared visible RGB and masks of all 360 embedded resources against the resized, alpha-thresholded delivered source composites. Native 64px visible pixels exactly match the delivered source composites. The native32 disk-loader result is reviewed as delivered; selection of the separately prepared embedded32 resource is not assumed.
- Checked every native frame for binary effective opacity, opaque/fixed click pixel and empty canvas edges. All pass at all three sizes. The authored 5x5 saddle patch is invariant at native64; at smaller sizes only the click pixel, rather than a rescaled 5x5 neighborhood, is required to remain fixed.
- Compared all native transparent GIF masks to fresh native renders. All masks match exactly. Tested every native invariant opaque pixel for color flicker against fresh renders and the preserved pre-turn baseline. Current flickering invariant-pixel count and channel span are zero for every role/size.
- Parsed all current GIF block tables, disposal/transparency controls and stored delays. Each quantized animation has one shared palette, no per-frame palette drift, disposal=2, transparent index zero, and binary decoded alpha. A separate hidden-RGB probe confirms clear pixels do not affect the selected palette.
- Checked the shared source grading: all six still-piece alpha channels are unchanged by `rich_materials`; loader grading is the same fixed operation for both horses before resizing/deformation. Delivered still pieces match original assets. Pointer and hand illustrations are not accidentally horse-graded.
- Ran the delivered trial helper with `--check-load` on exact copies under `trial_load/`. It loaded all three ANI files at32 and64, created no window, and changed no scheme. This proves loading only.
- Verified all identity/source/implementation/preview/trial/validation hashes, and measured every release artifact in `audit_acceptance.json`. Registry cursor/mouse/accessibility values equal both audit-start values and the preserved baseline.

## Visual and implementation review

Viewed the actual native 32px and64px contact sheets and new audit grids for every index, source composite contact sheets, six generated still pieces, current HTML screenshot, and current GIF frame data. The rigid arrow retains aligned head/shaft and its contact point. The link horse shows a lift, held raised pose, return/strike and ground pulse; the pulse is a looping effect independent of mouse clicks. The shared gallop has attached, substantial forelegs and a continuous torso/shoulder mass through support and recovery. Far legs retain intentional depth shading. Flame tail, cape and cuff/heel flame roots remain attached in the reviewed composites; no canvas clipping was found. Horse muzzle/ear/tack and pumpkin accents remain readable at64px; fine face/trim detail collapses to very few pixels at32px. This is a retained resolution limit, rather than newly drawn facial acting.

The six horse PNG pieces each contain one generated still illustration. The delivered 24-frame gallop and48-frame stomp are kinematic rig composites using those pieces; pointer and hand use one still source each with isolated ornaments and periodic image warps. These are not independently drawn source poses, and flame motion is not physical simulation.

Measured wrap transitions fall within ordinary adjacent-frame channel-delta ranges. For the shared gallop at64px the seam changes1216 pixels versus an ordinary adjacent mean1192.3; seam mean RGBA-channel delta6.35 versus maximum ordinary7.56. These pixel measures and pose-grid inspection did not reveal a special wrap jump. They do not prove fluid character motion or human-perceived cadence.

## Color and stored timing results

| Role | Native invariant opaque pixels, 32/48/64 | Baseline GIF flicker count, 32/48/64 | Current GIF flicker count | ANI/GIF loop |
|---|---:|---:|---:|---:|

| pointer | 175/389/695 | 0/322/619 | 0/0/0 | 1600 ms |

| link | 7/19/33 | 7/19/35 | 0/0/0 | 1600 ms |

| busy | 4/16/25 | 4/16/25 | 0/0/0 | 800 ms |


Native ANI timing remains2 jiffies per frame (nominal30fps). GIF delays alternate the necessary30/40ms centisecond values without changing total loop length: pointer/link1600ms, busy800ms. The combined review is1600ms with the busy loop repeated twice. Browser wall-clock timing was not measured. GIF palettes remain lossy to native true color: see per-size maximum quantization differences in `measurements.json`; stability does not mean pixel-identical RGB.

The current2x `stomp-rich-color.gif` was independently decoded and compared with the nearest enlargement of `native_transparent_previews/link_64px.gif`: every visible RGB pixel, mask and delay is exact. Its per-frame palette-index remapping is lossless and adds no second quantization. All native/source alpha masks match the pre-turn Stomp baseline.

## Browser preview review

The auditor reviewed the HTML/CSS/JavaScript, referenced GIF dimensions and supplied live-browser JSON/screenshot evidence. The parent agent operated the live browser. All nine images load at native32/native64 and labelled128px nearest inspection; CSS opacity is1 and filters are absent at DPR1. Live evidence covers all five backgrounds, contact toggle, three role selections and a semantic target-click count change. The automated count check does not establish human aiming accuracy. Descriptions match the current arrow/stomp/gallop art and there is no obsolete banner. The target pad correctly uses a static native32 PNG and does not claim browser ANI playback. Browser wall-clock cadence remains unmeasured.

## Exact accepted bytes

| Delivered ANI | SHA256 |
|---|---|

| busy.ani | `2625c7f8588a18be3a5353950a6866f5fbc2f812b29599eb4dc1f2aab4a66ef4` |

| link.ani | `6031bc86b171e49743a5981d95a7b05f486724063b92f673017a4aa319bb21ee` |

| pointer.ani | `50baad107c2563e7d53d1cacb012b348886f849c373a105378d41d9446f78729` |


| Binding | SHA256 |
|---|---|

| build_identity.json | `49f94dd7a22f3919abec6406722d5ab6518646882026686a68f1410e49d9bd80` |

| preview.html | `c186326cc286631ae87b4974fe364c0ec39d237f1bc99ec2e432b5d7eb6a0036` |

| animation_manifest.json | `0daf0e742957e318fdfe83cc4d5127e8197969211de8e59361d4856d8f7ae57f` |

| review.gif | `20c71950e5867e641ea922d37ff013208bdcfee853e52f0c3d05560ed306a611` |

| stomp-rich-color.gif | `e9bab302dc982f4784acefd1b536cd26aa5f3bd751eec7967873d2890527be74` |


| Reviewed implementation | SHA256 |
|---|---|

| engine/horseman_motion_study.py | `9e99f24693528b9d12b4311394c95fd112bdc4d4413219456acd72d57751c324` |

| engine/horseman_stomp_study.py | `855988e973243952d9dc332aaa9a8ce6bd18883e2c61492ab19ff86f531c8bec` |

| engine/horseman_motion_preview.py | `745e9f00210c74fdb8ff0350c48cfe36fe33023b5bcf5eef2b73096341e7d069` |

| engine/horseman_color.py | `a2d0de5fef5be14163d95a2c88d33b4f7e69a56d4998cec6b477328667d626fd` |

| engine/preview_gen.py | `39456e8a5c05d7b3ff318fb18cea40fbab2119d275cc9eb12d8d048a95a23a5c` |

| engine/ani_compiler.py | `686981d0c1c927079814d338a14141fe892129c36f37be3036aa099fccf6b9f3` |

| validate_muse_pack.py | `98a4c6a03be5d0764d4ff283f464d37219b12c8170947d82f6b16fe779f17468` |

| verify_pack.py | `7f40ecf43af61cecf812fa1b90ebb6589e8d9417c1ad8fd5eed6939dc1d3f893` |

| enlarge_native_gif_losslessly.py | `855c3a002d5e3ca2bd11d8b0e8a38e508c8353d0e94e1cfbafddb63d89b163dc` |

| try_horseman_motion_study.py | `daf43e9e5be47913f496d91617bfadd49dbbe27897a083f63c2d7bd0372d3dae` |

| build_horseman_stomp_study.py | `4ecde0a2b44df099a939c47f370a3226c41549892589cfae2b3c133a214b739a` |


All source composites, copied original sources, previews, validation records, native sheets, README and packaged trial files are individually bound by `artifact_files` in `audit_acceptance.json`. Supplied browser/color evidence is individually bound by `evidence_files`. The detailed actual-native measurements and scripts are retained beside this report.

## Findings and limits

No P0/P1 artwork, motion, encoding, or preview findings remain. No rebuild was needed after independent review. Remaining disclosed limits are dense face/trim detail at32px, GIF palette color loss, unmeasured browser wall-clock cadence, unverified automatic window/equipped playback, unverified human aiming accuracy and unverified fluid character motion. No cursor scheme was changed and no native trial window was opened.
