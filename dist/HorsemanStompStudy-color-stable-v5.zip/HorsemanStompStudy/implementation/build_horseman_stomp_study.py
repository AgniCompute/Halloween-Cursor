"""Build the three-role Horseman stomp proof; never equip a cursor."""
import hashlib
import json
import shutil
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageSequence

from engine.ani_compiler import save_ani
from engine.preview_gen import generate_animated_gif, gif_timing
from engine.horseman_motion_preview import write_preview
from validate_muse_pack import validate_pack
from verify_pack import verify_pack
from enlarge_native_gif_losslessly import main as enlarge_native_gif


ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'cursor_sets' / 'HorsemanStompStudy'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def binary(frame):
    frame = frame.convert('RGBA')
    frame.putalpha(frame.getchannel('A').point(lambda value: 255 if value >= 128 else 0))
    return frame


def relative_source(path, asset_folder):
    """Resolve descriptions that name a source file or a workspace-relative path."""
    path = Path(path)
    if not path.is_absolute():
        candidate = ROOT / path
        path = candidate if candidate.is_file() else asset_folder / path
        if not path.suffix:
            path = path.with_suffix('.png')
    path = path.resolve()
    if not path.is_file():
        raise ValueError(f'Missing declared source asset: {path}')
    return path.relative_to(ROOT).as_posix()


def write_review_animation(folder, descriptions):
    """A labeled comparison made from native GIFs, with their palette limits."""
    roles = ('pointer', 'link', 'busy')
    animations = {}
    for role in roles:
        animations[role] = {}
        for size in (32, 64):
            with Image.open(folder / 'native_transparent_previews' / f'{role}_{size}px.gif') as animation:
                animations[role][size] = [frame.convert('RGBA') for frame in ImageSequence.Iterator(animation)]
    try:
        title_font = ImageFont.truetype('C:/Windows/Fonts/segoeuib.ttf', 15)
        label_font = ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf', 11)
    except OSError:
        title_font = label_font = ImageFont.load_default()
    frames = []
    for step in range(48):
        canvas = Image.new('RGB', (720, 232), '#f3eee5')
        draw = ImageDraw.Draw(canvas)
        for column, role in enumerate(roles):
            left = column * 240
            if column:
                draw.line((left, 15, left, 215), fill='#d6c6d9')
            draw.text((left + 16, 12), descriptions[role][0], fill='#422948', font=title_font)
            draw.text((left + 16, 39), 'Windows GIF frames', fill='#6b5670', font=label_font)
            for size, origin, scale in ((32, (left + 17, 154), 1),
                                        (64, (left + 77, 58), 2)):
                native = animations[role][size]
                sprite = native[step % len(native)]
                if scale > 1:
                    sprite = sprite.resize((size * scale, size * scale), Image.Resampling.NEAREST)
                canvas.paste(sprite, origin, sprite)
            draw.text((left + 16, 196), '32px actual size', fill='#6b5670', font=label_font)
            draw.text((left + 104, 196), '64px shown at 2x', fill='#6b5670', font=label_font)
        draw.text((16, 216), 'Enlarged review - native GIF palette colors; busy loop repeats twice.',
                  fill='#6b5670', font=label_font)
        frames.append(canvas)
    generate_animated_gif(frames, str(folder / 'review.gif'), scale_factor=1, jiffies=2)


def main():
    # Keep import deferred so the preview module can be inspected before artwork exists.
    from engine import horseman_stomp_study as artwork

    for name in ('sources', 'previews', 'embedded_previews', 'source_art'):
        (OUT / name).mkdir(parents=True, exist_ok=True)
    asset_folder = Path(artwork.ASSETS).resolve()
    shutil.copytree(asset_folder, OUT / 'source_art', dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    roles = artwork.build_roles()
    shutil.copy2(ROOT / 'try_horseman_motion_study.py', OUT / 'try_horseman_motion_study.py')
    (OUT / 'TRY_HORSEMAN_STOMP.cmd').write_text(
        '@echo off\ncd /d "%~dp0"\npython try_horseman_motion_study.py --pack "%~dp0"\nif errorlevel 1 pause\n',
        encoding='utf-8')
    if set(roles) != {'pointer', 'link', 'busy'}:
        raise ValueError('This proof must contain exactly pointer, link, and busy')
    manifests = []
    for role, (frames, hotspot, tick) in roles.items():
        if not frames or any(frame.mode != 'RGBA' or frame.size != (64, 64) for frame in frames):
            raise ValueError(f'{role} must provide nonempty 64px RGBA source frames')
        if tick < 1:
            raise ValueError(f'{role} has an invalid jiffy duration')
        for frame in frames:
            if set(frame.getchannel('A').tobytes()) - {0, 255}:
                raise ValueError(f'{role} must provide binary source alpha for opaque24 encoding')
        title, description, described_assets = artwork.DESCRIPTIONS[role]
        provenance = dict(artwork.PROVENANCE[role])
        source_names = provenance.get('source_assets', described_assets)
        sources = [relative_source(path, asset_folder) for path in source_names]
        # Only remove prior source frames of this exact proof role, inside this output.
        for old in (OUT / 'sources').glob(f'{role}_*.png'):
            old.unlink()
        for index, frame in enumerate(frames):
            frame.save(OUT / 'sources' / f'{role}_{index:02}.png')
        save_ani(frames, str(OUT / f'{role}.ani'), *hotspot,
                 jiffies=tick, opaque=True, sizes=(64, 48, 32))
        generate_animated_gif(frames, str(OUT / 'previews' / f'{role}.gif'),
                              scale_factor=2, jiffies=tick)
        for size in (32, 64):
            prepared = [binary(frame.resize((size, size), Image.Resampling.LANCZOS)) for frame in frames]
            generate_animated_gif(prepared, str(OUT / 'embedded_previews' / f'{role}_{size}px.gif'),
                                  scale_factor=1, jiffies=tick)
        manifest = dict(provenance)
        manifest.update(
            role=role, title=title, motion=description, source_assets=sources,
            source_frames_note='Source poses and source pieces are described by provenance; the loop consists of code-rigged composite frames, not independently drawn poses.',
            encoding='24-bit BGR with embedded 64/48/32 cursor sizes and 1-bit AND transparency masks',
            alpha_policy='0/255 source alpha; prepared resized resources thresholded at 128',
            composite_frames=len(frames), unique_composites=len({frame.tobytes() for frame in frames}),
            hotspot=list(hotspot), jiffies=tick, loop_ms=round(len(frames) * tick * 1000 / 60),
            independently_hand_drawn=False, physical_flame_simulation=False,
            automatic_window_playback_verified=False, automatic_equipped_playback_verified=False,
            fluid_character_motion_verified=False,
            gif_palette_policy='One opaque-color master palette per animation; no dithering; index zero reserved for transparency',
        )
        manifests.append(manifest)
    manifest_path = OUT / 'animation_manifest.json'
    manifest_path.write_text(json.dumps(manifests, indent=2), encoding='utf-8')

    count = max(len(item[0]) for item in roles.values())
    sheet = Image.new('RGB', (112 + count * 64, len(roles) * 98), '#211b29')
    draw = ImageDraw.Draw(sheet)
    for row, role in enumerate(roles):
        draw.text((8, row * 98 + 23), role, fill='white')
        for step, frame in enumerate(roles[role][0]):
            sheet.paste(frame, (112 + step * 64, row * 98), frame)
            draw.text((112 + step * 64, row * 98 + 70), str(step), fill='#ccb9ce')
    sheet.save(OUT / 'source_contact.png')

    native_validation, _ = validate_pack(OUT)
    for item in manifests:
        item['native_hotspots'] = {size: native_validation[item['role']][size]['hotspot']
                                   for size in ('32', '48', '64')}
        item['preview_source'] = 'transparent RGBA recovered from actual Windows disk-loaded black/white frame renders'
        item['size32_sampling_note'] = 'The native32 preview shows the actual disk-loader result; selection of the prepared embedded32 resource is not assumed.'
    manifest_path.write_text(json.dumps(manifests, indent=2), encoding='utf-8')
    verification = verify_pack(OUT, expected_frames={role: item[0] for role, item in roles.items()},
                               minimum_unique_frames=2, require_disk_fidelity=True)
    # The shared verifier reserves 17 rows. Retain the three exact rendered rows
    # and remove only unused space from this proof's evidence images.
    for size in (32, 64):
        path = OUT / f'windows_render_check_{size}px.png'
        with Image.open(path) as native_sheet:
            trimmed = native_sheet.crop((0, 0, native_sheet.width, len(roles) * (size + 36)))
        trimmed.save(path)
        if size == 64:
            trimmed.save(OUT / 'windows_render_check.png')
    write_review_animation(OUT, artwork.DESCRIPTIONS)
    enlarge_native_gif(OUT / 'native_transparent_previews' / 'link_64px.gif',
                       OUT / 'stomp-rich-color.gif')
    write_preview(OUT, roles, artwork.DESCRIPTIONS,
                  native_hotspots={item['role']: item['native_hotspots'] for item in manifests})
    preview_path = OUT / 'preview.html'
    preview_path.write_text(preview_path.read_text(encoding='utf-8').replace('a pointing gauntlet for links', 'a stomping Horseman for links'), encoding='utf-8')
    (OUT / 'README.txt').write_text(
        'HORSEMAN STOMP STUDY\n\n'
        'A separate three-role proof: stylized default arrow, stomping Horseman link, articulated Horseman busy loop.\n'
        'Generated source pieces are assembled and moved with a code rig. Composite frames are not independently hand-drawn poses. Flame motion is procedural, not physical simulation.\n\n'
        'Open preview.html for actual Windows-rendered 32px and 64px GIFs, 2x inspection, five backgrounds, fixed contact markers, and a still-frame browser aiming test.\n'
        'ANI files embed 64px, 48px, and 32px resources using 24-bit colour and 1-bit transparency masks.\n'
        'This proof has no installer and does not modify the existing 17-role pack or equipped cursor scheme.\n\n'
        'Native checks load the delivered files and force each DrawIconEx index. These checks verify frame rendering and contacts, not automatic Windows playback or fluid character motion.\n'
        'Browser target clicks exercise static cursor contacts; automated semantic clicks do not establish human aiming accuracy.\n'
        'For a temporary native trial, run TRY_HORSEMAN_STOMP.cmd in this folder. Three regions show arrow, stomp and gallop; press 1 for 32px, 2 for 64px, or Esc to close. This uses a window-local cursor and leaves the equipped scheme unchanged. Successful loading alone does not verify automatic playback.\n'
        'Both horses share fixed source-piece color grading before motion. GIFs use one master palette per loop to keep unchanged pixels steady; moving limbs and fire still change intentionally.\n'
        'review.gif compares native 32px GIF frames at actual size with native 64px GIF frames enlarged 2x. It uses native-GIF palette colors; the busy loop repeats twice during the 1600ms comparison.\n'
        'See animation_manifest.json, muse_native_validation.json, validation.json, build_identity.json, native contact sheets, and GIFs for the exact build evidence.\n',
        encoding='utf-8')
    identity = dict(
        pack=str(OUT), art_version='horseman-stomp-color-stable-v5', proof_roles=list(roles),
        files={path.name: digest(path) for path in OUT.glob('*.ani')},
        source_files={path.relative_to(ROOT).as_posix(): digest(path)
                      for path in sorted(asset_folder.rglob('*'))
                      if path.is_file() and path.suffix != '.pyc' and '__pycache__' not in path.parts},
        implementation_files={name: digest(ROOT / name) for name in (
            'engine/horseman_motion_study.py', 'engine/horseman_stomp_study.py', 'engine/horseman_motion_preview.py',
            'engine/horseman_color.py', 'engine/preview_gen.py', 'engine/ani_compiler.py',
            'validate_muse_pack.py', 'verify_pack.py', 'enlarge_native_gif_losslessly.py',
            'try_horseman_motion_study.py',
            'build_horseman_stomp_study.py')},
        preview_sha256=digest(OUT / 'preview.html'), manifest_sha256=digest(manifest_path),
        review_gif_sha256=digest(OUT / 'review.gif'),
        inspection_gif_sha256=digest(OUT / 'stomp-rich-color.gif'),
        preview_files={path.relative_to(OUT).as_posix(): digest(path)
                       for name in ('previews', 'embedded_previews', 'native_previews', 'native_transparent_previews', 'browser_cursors')
                       for path in sorted((OUT / name).iterdir()) if path.is_file()},
        validation_files={name: digest(OUT / name) for name in ('validation.json', 'muse_native_validation.json')},
        trial_files={name: digest(OUT / name) for name in ('try_horseman_motion_study.py', 'TRY_HORSEMAN_STOMP.cmd')},
        native_validation_sizes=[32, 48, 64], native_validation_roles=sorted(native_validation),
        native_fidelity_roles=[item['file'] for item in verification],
        scheme_changed=False, automatic_window_playback_verified=False,
    )
    (OUT / 'build_identity.json').write_text(json.dumps(identity, indent=2), encoding='utf-8')
    print(OUT)


if __name__ == '__main__':
    main()
