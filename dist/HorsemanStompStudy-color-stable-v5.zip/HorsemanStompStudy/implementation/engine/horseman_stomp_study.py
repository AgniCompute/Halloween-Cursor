"""Separate link stomp: three planted feet and one lift, pause, and strike."""
from copy import deepcopy
import math
from PIL import Image, ImageDraw
from . import horseman_motion_study as m

ASSETS=m.ASSETS
DESCRIPTIONS=deepcopy(m.DESCRIPTIONS)
PROVENANCE=deepcopy(m.PROVENANCE)
DESCRIPTIONS['link']=('Ember stomp','A Horseman in deep violet and ember gold lifts and stamps one hoof, releasing a short gold pulse on impact. The pulse repeats with the animation, not mouse clicks.', ['busy-rig-source.png'])
PROVENANCE['link']=deepcopy(PROVENANCE['busy'])
PROVENANCE['link']['motion_method']='six generated still pieces; fixed world hoof targets for three legs; near fore hoof follows eased lift, held raised pose, faster strike and rest; body impact settle; tapered 6.0-to-4.4px foreleg anatomical contour with 2.6px forward knee bend in stance, and rooted cape/tail deformation; 48 composites at 30fps'
PROVENANCE['link']['fixed_contact_note']='5x5 saddle contact patch preserved across composites'
PROVENANCE['link']['color_effect_note']=m.COLOR_NOTE + ' A gold ground pulse expands after the stomp, independent of mouse input.'

def ease(t):
    t=max(0,min(1,t))
    return t*t*(3-2*t)

def lift_amount(p):
    if p<.15: return 0
    if p<.35: return ease((p-.15)/.2)
    if p<.5: return 1
    if p<.61: return 1-ease((p-.5)/.11)
    return 0

def grounded_leg(im,kind,root,target,raised,shade):
    # Reuse the reviewed painter/IK with explicit world-space hoof targets.
    # The substitution is scoped to this single call and always restored.
    previous=m.hoof_path
    m.hoof_path=lambda _kind,_x,_phase:(target[0],target[1],not raised)
    try:
        m.leg(im,kind,root,.24+.1216*raised if raised else .12,shade)
    finally:
        m.hoof_path=previous

def impact_pulse(p):
    layer=m.canvas()
    if .61<=p<.88:
        u=(p-.61)/.27
        r=2+8*ease(u)
        color=tuple(round(a+(b-a)*u) for a,b in zip((255,235,133),(72,27,87)))+(255,)
        d=ImageDraw.Draw(layer)
        box=tuple(round(v*m.SCALE) for v in (21-r,54-r*.36,21+r,54+r*.36))
        if u<.45:
            d.ellipse(box,outline=color,width=round(2*m.SCALE))
        else:
            coverage=1-ease((u-.45)/.55)
            span=90*coverage
            width=max(1,round((.75+1.25*coverage)*m.SCALE))
            for quadrant in range(4):
                start=quadrant*90+(90-span)/2
                d.arc(box,start,start+span,fill=color,width=width)
    return layer

def stomp():
    frames=[]
    for index in range(48):
        p=index/48
        lift=lift_amount(p)
        bob=-.45*lift
        if .61<=p<.78:
            bob+=.75*math.sin(math.pi*(p-.61)/.17)**2
        im=m.canvas()
        tail=m.resize_on_canvas(m.load('tail'),(43,21+bob,16,16))
        im.alpha_composite(m.flow(tail,(44,35+bob),p-.2,'flame',1.2))
        grounded_leg(im,'front',(24,37+bob),(27,54),False,.64)
        grounded_leg(im,'rear',(39,37+bob),(38,53.5),False,.64)
        cape=m.resize_on_canvas(m.load('cape'),(30,15+bob,24,12.4))
        im.alpha_composite(m.flow(cape,(31,19+bob),p-.22,'ribbon',1))
        im.alpha_composite(m.resize_on_canvas(m.load('body'),(7,7+bob,39,34)))
        grounded_leg(im,'rear',(41,35+bob),(46,53.5),False,1)
        grounded_leg(im,'front',(22,35+bob),(21-5*lift,54-9*lift),lift,1)
        base=impact_pulse(p)
        base.alpha_composite(im)
        frames.append(m.finish(base))
    contact=m.find_contact(frames[0],(36,36))
    return [m.still_contact(f,frames[0],contact,2) for f in frames],contact,2

def build_roles():
    return {'pointer':m.pointer_cursor(),'link':stomp(),'busy':m.busy()}
