"""Nearest 2x native GIF inspection preserving each visible palette color."""
import argparse
from pathlib import Path
import numpy as np
from PIL import Image, ImageSequence

def main(source,destination):
    frames=[]; delays=[]; expected=[]
    with Image.open(source) as src:
        for frame in ImageSequence.Iterator(src):
            pixels=np.array(frame.convert('RGBA').resize((frame.width*2,frame.height*2),Image.Resampling.NEAREST))
            expected.append(pixels)
            delays.append(frame.info.get('duration',30))
            colors=sorted(set(map(tuple,pixels[:,:,:3][pixels[:,:,3]>0])))
            assert len(colors)<=255,'Too many opaque colors for a lossless transparent GIF'
            lookup={color:i+1 for i,color in enumerate(colors)}
            indices=np.array([lookup[tuple(rgb)] if alpha else 0 for rgb,alpha in
                              zip(pixels[:,:,:3].reshape(-1,3),pixels[:,:,3].ravel())],dtype=np.uint8).reshape(pixels.shape[:2])
            out=Image.fromarray(indices)
            palette=[0,0,0]+[value for color in colors for value in color]
            out.putpalette(palette+[0]*(768-len(palette)))
            out.info['transparency']=0
            frames.append(out)
    frames[0].save(destination,save_all=True,append_images=frames[1:],duration=delays,
                   loop=0,disposal=2,transparency=0,optimize=False)
    with Image.open(destination) as result:
        actual=[np.array(frame.convert('RGBA')) for frame in ImageSequence.Iterator(result)]
    assert len(actual)==len(expected)
    for a,b in zip(actual,expected):
        assert np.array_equal(a[:,:,3],b[:,:,3])
        assert np.array_equal(a[:,:,:3][a[:,:,3]>0],b[:,:,:3][b[:,:,3]>0])
    print(f'{len(actual)} enlarged frames verified: exact visible RGB and opacity.')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('source',type=Path)
    parser.add_argument('destination',type=Path)
    args=parser.parse_args()
    main(args.source,args.destination)
